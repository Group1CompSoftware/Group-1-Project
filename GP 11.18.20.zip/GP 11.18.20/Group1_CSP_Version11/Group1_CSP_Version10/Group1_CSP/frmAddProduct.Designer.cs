﻿namespace Group1_CSP
{
    partial class frmAddProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblProductID = new System.Windows.Forms.Label();
            this.lblProductName = new System.Windows.Forms.Label();
            this.lblProductPrice = new System.Windows.Forms.Label();
            this.lblImageID = new System.Windows.Forms.Label();
            this.lblAmountInStock = new System.Windows.Forms.Label();
            this.tbxProductID = new System.Windows.Forms.TextBox();
            this.tbxProductName = new System.Windows.Forms.TextBox();
            this.tbxProductPrice = new System.Windows.Forms.TextBox();
            this.tbxImageID = new System.Windows.Forms.TextBox();
            this.tbxAmountInStock = new System.Windows.Forms.TextBox();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblProductID
            // 
            this.lblProductID.AutoSize = true;
            this.lblProductID.ForeColor = System.Drawing.Color.White;
            this.lblProductID.Location = new System.Drawing.Point(37, 14);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(61, 13);
            this.lblProductID.TabIndex = 0;
            this.lblProductID.Text = "Product ID:";
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.ForeColor = System.Drawing.Color.White;
            this.lblProductName.Location = new System.Drawing.Point(20, 40);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(78, 13);
            this.lblProductName.TabIndex = 1;
            this.lblProductName.Text = "Product Name:";
            // 
            // lblProductPrice
            // 
            this.lblProductPrice.AutoSize = true;
            this.lblProductPrice.ForeColor = System.Drawing.Color.White;
            this.lblProductPrice.Location = new System.Drawing.Point(24, 66);
            this.lblProductPrice.Name = "lblProductPrice";
            this.lblProductPrice.Size = new System.Drawing.Size(74, 13);
            this.lblProductPrice.TabIndex = 2;
            this.lblProductPrice.Text = "Product Price:";
            // 
            // lblImageID
            // 
            this.lblImageID.AutoSize = true;
            this.lblImageID.ForeColor = System.Drawing.Color.White;
            this.lblImageID.Location = new System.Drawing.Point(45, 92);
            this.lblImageID.Name = "lblImageID";
            this.lblImageID.Size = new System.Drawing.Size(53, 13);
            this.lblImageID.TabIndex = 3;
            this.lblImageID.Text = "Image ID:";
            // 
            // lblAmountInStock
            // 
            this.lblAmountInStock.AutoSize = true;
            this.lblAmountInStock.ForeColor = System.Drawing.Color.White;
            this.lblAmountInStock.Location = new System.Drawing.Point(9, 118);
            this.lblAmountInStock.Name = "lblAmountInStock";
            this.lblAmountInStock.Size = new System.Drawing.Size(89, 13);
            this.lblAmountInStock.TabIndex = 4;
            this.lblAmountInStock.Text = "Amount In Stock:";
            // 
            // tbxProductID
            // 
            this.tbxProductID.Location = new System.Drawing.Point(104, 11);
            this.tbxProductID.Name = "tbxProductID";
            this.tbxProductID.Size = new System.Drawing.Size(100, 20);
            this.tbxProductID.TabIndex = 5;
            // 
            // tbxProductName
            // 
            this.tbxProductName.Location = new System.Drawing.Point(104, 37);
            this.tbxProductName.Name = "tbxProductName";
            this.tbxProductName.Size = new System.Drawing.Size(100, 20);
            this.tbxProductName.TabIndex = 6;
            // 
            // tbxProductPrice
            // 
            this.tbxProductPrice.Location = new System.Drawing.Point(104, 63);
            this.tbxProductPrice.Name = "tbxProductPrice";
            this.tbxProductPrice.Size = new System.Drawing.Size(100, 20);
            this.tbxProductPrice.TabIndex = 7;
            // 
            // tbxImageID
            // 
            this.tbxImageID.Location = new System.Drawing.Point(104, 89);
            this.tbxImageID.Name = "tbxImageID";
            this.tbxImageID.Size = new System.Drawing.Size(100, 20);
            this.tbxImageID.TabIndex = 8;
            // 
            // tbxAmountInStock
            // 
            this.tbxAmountInStock.Location = new System.Drawing.Point(104, 115);
            this.tbxAmountInStock.Name = "tbxAmountInStock";
            this.tbxAmountInStock.Size = new System.Drawing.Size(100, 20);
            this.tbxAmountInStock.TabIndex = 9;
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(12, 142);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(192, 23);
            this.btnConfirm.TabIndex = 10;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(12, 171);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(192, 23);
            this.btnCancel.TabIndex = 11;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // frmAddProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(218, 205);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.tbxAmountInStock);
            this.Controls.Add(this.tbxImageID);
            this.Controls.Add(this.tbxProductPrice);
            this.Controls.Add(this.tbxProductName);
            this.Controls.Add(this.tbxProductID);
            this.Controls.Add(this.lblAmountInStock);
            this.Controls.Add(this.lblImageID);
            this.Controls.Add(this.lblProductPrice);
            this.Controls.Add(this.lblProductName);
            this.Controls.Add(this.lblProductID);
            this.Name = "frmAddProduct";
            this.Text = "Add Product";
            this.Load += new System.EventHandler(this.frmAddProduct_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblProductID;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label lblProductPrice;
        private System.Windows.Forms.Label lblImageID;
        private System.Windows.Forms.Label lblAmountInStock;
        private System.Windows.Forms.TextBox tbxProductID;
        private System.Windows.Forms.TextBox tbxProductName;
        private System.Windows.Forms.TextBox tbxProductPrice;
        private System.Windows.Forms.TextBox tbxImageID;
        private System.Windows.Forms.TextBox tbxAmountInStock;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnCancel;
    }
}