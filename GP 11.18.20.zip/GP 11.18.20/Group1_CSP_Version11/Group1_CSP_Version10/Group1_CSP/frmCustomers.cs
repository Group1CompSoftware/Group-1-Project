﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1_CSP
{
    public partial class frmCustomers : Form
    {

        //declaring variables
        const int SIZE = 10;
        public static double total = 0;
        Items[] items = new Items[SIZE];
        public static List<string> _orderForm = new List<string>();

        //creating Item structure for items on form
        struct Items
        {
            public string name;
            public double cost;
            public int originalQty;
            public int quantity;
        }

        public frmCustomers()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //closes form
            this.Close();
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            //opens checkout form
            frmCheckout fc = new frmCheckout();
            fc.ShowDialog();

        }

        private void frmCustomers_Load(object sender, EventArgs e)
        {

            
            //filling labels with AmountInStock for each product
            ProgOps.AmountInStockCommand(lblApplesInventory,"Apples");
            ProgOps.AmountInStockCommand(lblBananaInventory, "Bananas");
            ProgOps.AmountInStockCommand(lblGrapesInventory, "Grapes");
            ProgOps.AmountInStockCommand(lblCarrotsInventory, "Carrots");
            ProgOps.AmountInStockCommand(lblOrangesInventory, "Oranges");
            ProgOps.AmountInStockCommand(lblEggsInventory, "Eggs");
            ProgOps.AmountInStockCommand(lblSteakInventory, "Steak");
            ProgOps.AmountInStockCommand(lblBreadInventory, "Bread");
            ProgOps.AmountInStockCommand(lblMilkInventory, "Milk");
            ProgOps.AmountInStockCommand(lblChickenInventory, "Chicken");

            //filling labels with ProductPrice for each product
            ProgOps.ProductPriceCommand(lblApplesPrice, "Apples");
            ProgOps.ProductPriceCommand(lblBananasPrice, "Bananas");
            ProgOps.ProductPriceCommand(lblGrapesPrice, "Grapes");
            ProgOps.ProductPriceCommand(lblCarrotsPrice, "Carrots");
            ProgOps.ProductPriceCommand(lblOrangesPrice, "Oranges");
            ProgOps.ProductPriceCommand(lblEggsPrice, "Eggs");
            ProgOps.ProductPriceCommand(lblSteakPrice, "Steak");
            ProgOps.ProductPriceCommand(lblBreadPrice, "Bread");
            ProgOps.ProductPriceCommand(lblMilkPrice, "Milk");
            ProgOps.ProductPriceCommand(lblChickenPrice, "Chicken");


            //creating item objects
            items[0].name = "Apples";
            items[0].cost = Convert.ToDouble(lblApplesPrice.Text);
            items[0].originalQty = Convert.ToInt32(lblApplesInventory.Text);
            items[0].quantity = Convert.ToInt32(lblApplesInventory.Text);

            items[1].name = "Bananas";
            items[1].cost = Convert.ToDouble(lblBananasPrice.Text);
            items[1].originalQty = Convert.ToInt32(lblBananaInventory.Text);
            items[1].quantity = Convert.ToInt32(lblBananaInventory.Text);

            items[2].name = "Grapes";
            items[2].cost = Convert.ToDouble(lblGrapesPrice.Text);
            items[2].originalQty = Convert.ToInt32(lblGrapesInventory.Text);
            items[2].quantity = Convert.ToInt32(lblGrapesInventory.Text);

            items[3].name = "Carrots";
            items[3].cost = Convert.ToDouble(lblCarrotsPrice.Text);
            items[3].originalQty = Convert.ToInt32(lblCarrotsInventory.Text);
            items[3].quantity = Convert.ToInt32(lblCarrotsInventory.Text);

            items[4].name = "Oranges";
            items[4].cost = Convert.ToDouble(lblOrangesPrice.Text);
            items[4].originalQty = Convert.ToInt32(lblOrangesInventory.Text);
            items[4].quantity = Convert.ToInt32(lblOrangesInventory.Text);

            items[5].name = "Eggs";
            items[5].cost = Convert.ToDouble(lblEggsPrice.Text);
            items[5].originalQty = Convert.ToInt32(lblEggsInventory.Text);
            items[5].quantity = Convert.ToInt32(lblEggsInventory.Text);

            items[6].name = "Steak";
            items[6].cost = Convert.ToDouble(lblSteakPrice.Text);
            items[6].originalQty = Convert.ToInt32(lblSteakInventory.Text);
            items[6].quantity = Convert.ToInt32(lblSteakInventory.Text);

            items[7].name = "Bread";
            items[7].cost = Convert.ToDouble(lblBreadPrice.Text);
            items[7].originalQty = Convert.ToInt32(lblBreadInventory.Text);
            items[7].quantity = Convert.ToInt32(lblBreadInventory.Text);

            items[8].name = "Milk";
            items[8].cost = Convert.ToDouble(lblMilkPrice.Text);
            items[8].originalQty = Convert.ToInt32(lblMilkInventory.Text);
            items[8].quantity = Convert.ToInt32(lblMilkInventory.Text);

            items[9].name = "Chicken";
            items[9].cost = Convert.ToDouble(lblChickenPrice.Text);
            items[9].originalQty = Convert.ToInt32(lblChickenInventory.Text);
            items[9].quantity = Convert.ToInt32(lblChickenInventory.Text);
        }


        private void pbxApples_Click(object sender, EventArgs e)
        {
            //decreases quantity and adds to total until quantity is 0
            if (rbAdd.Checked == true)
            {
                while (items[0].quantity > 0)
                {
                    //ProgOps.UpdateAmountInStock(lblApplesInventory, "Apples");
                    items[0].quantity -= 1;
                    total += items[0].cost;
                    break;
                }
                
            }
            //increases quantity and subtracts from total until quantity is back to original quantity
           if (rbDelete.Checked == true)
           {
                while (items[0].quantity != items[0].originalQty)
                {
                    items[0].quantity += 1;
                    total -= items[0].cost;
                    break;
                }
           }

            lblApplesInventory.Text = items[0].quantity.ToString(); 
            //add to the customers total
            lblTotal.Text = total.ToString("C");

            //displays message when sold out
            if (items[0].quantity == 0)
                MessageBox.Show("Apples are sold out!", "SOLD OUT");
        }

        private void pbxBananas_Click(object sender, EventArgs e)
        {
            //decreases quantity and adds to total until quantity is 0
            if (rbAdd.Checked == true)
            {
                while (items[1].quantity > 0)
                {
                    //ProgOps.UpdateAmountInStock(lblApplesInventory, "Apples");
                    items[1].quantity -= 1;
                    total += items[1].cost;
                    break;
                }

            }
            //increases quantity and subtracts from total until quantity is back to original quantity
            if (rbDelete.Checked == true)
            {
                while (items[1].quantity != items[1].originalQty)
                {
                    items[1].quantity += 1;
                    total -= items[1].cost;
                    break;
                }
            }

            lblBananaInventory.Text = items[1].quantity.ToString();
            //add to the customers total
            lblTotal.Text = total.ToString("C");

            //displays message when sold out
            if (items[1].quantity == 0)
                MessageBox.Show("Bananas are sold out!", "SOLD OUT");
        }

        private void pbxGrapes_Click(object sender, EventArgs e)
        {
            //decreases quantity and adds to total until quantity is 0
            if (rbAdd.Checked == true)
            {
                while (items[2].quantity > 0)
                {
                    //ProgOps.UpdateAmountInStock(lblApplesInventory, "Apples");
                    items[2].quantity -= 1;
                    total += items[2].cost;
                    //**********************************************************************************************************************
                    _orderForm.Add(items[2].name.ToString());
                    break;
                }

            }
            //increases quantity and subtracts from total until quantity is back to original quantity
            if (rbDelete.Checked == true)
            {
                while (items[2].quantity != items[2].originalQty)
                {
                    items[2].quantity += 1;
                    total -= items[2].cost;
                    break;
                }
            }

            lblGrapesInventory.Text = items[2].quantity.ToString();
            //add to the customers total
            lblTotal.Text = total.ToString("C");

            //displays message when sold out
            if (items[2].quantity == 0)
                MessageBox.Show("Grapes are sold out!", "SOLD OUT");
        }

        private void pbxCarrots_Click(object sender, EventArgs e)
        {
            //decreases quantity and adds to total until quantity is 0
            if (rbAdd.Checked == true)
            {
                while (items[3].quantity > 0)
                {
                    //ProgOps.UpdateAmountInStock(lblApplesInventory, "Apples");
                    items[3].quantity -= 1;
                    total += items[3].cost;
                    break;
                }

            }
            //increases quantity and subtracts from total until quantity is back to original quantity
            if (rbDelete.Checked == true)
            {
                while (items[3].quantity != items[3].originalQty)
                {
                    items[3].quantity += 1;
                    total -= items[3].cost;
                    break;
                }
            }

            lblCarrotsInventory.Text = items[3].quantity.ToString();
            //add to the customers total
            lblTotal.Text = total.ToString("C");

            if (items[3].quantity == 0)
                MessageBox.Show("Carrots are sold out!", "SOLD OUT");
        }

        private void pbxEggs_Click(object sender, EventArgs e)
        {
            //decreases quantity and adds to total until quantity is 0
            if (rbAdd.Checked == true)
            {
                while (items[5].quantity > 0)
                {
                    //ProgOps.UpdateAmountInStock(lblApplesInventory, "Apples");
                    items[5].quantity -= 1;
                    total += items[5].cost;
                    break;
                }

            }
            //increases quantity and subtracts from total until quantity is back to original quantity
            if (rbDelete.Checked == true)
            {
                while (items[5].quantity != items[5].originalQty)
                {
                    items[5].quantity += 1;
                    total -= items[5].cost;
                    break;
                }
            }

            lblEggsInventory.Text = items[5].quantity.ToString();
            //add to the customers total
            lblTotal.Text = total.ToString("C");

            if (items[5].quantity == 0)
                MessageBox.Show("Eggs are sold out!", "SOLD OUT");
        }

        private void pbxOranges_Click(object sender, EventArgs e)
        {
            //decreases quantity and adds to total until quantity is 0
            if (rbAdd.Checked == true)
            {
                while (items[4].quantity > 0)
                {
                    //ProgOps.UpdateAmountInStock(lblApplesInventory, "Apples");
                    items[4].quantity -= 1;
                    total += items[4].cost;
                    break;
                }

            }
            //increases quantity and subtracts from total until quantity is back to original quantity
            if (rbDelete.Checked == true)
            {
                while (items[4].quantity != items[4].originalQty)
                {
                    items[4].quantity += 1;
                    total -= items[4].cost;
                    break;
                }
            }

            lblOrangesInventory.Text = items[4].quantity.ToString();
            //add to the customers total
            lblTotal.Text = total.ToString("C");

            if (items[4].quantity == 0)
                MessageBox.Show("Oranges are sold out!", "SOLD OUT");
        }

        private void pbxSteak_Click(object sender, EventArgs e)
        {
            //decreases quantity and adds to total until quantity is 0
            if (rbAdd.Checked == true)
            {
                while (items[6].quantity > 0)
                {
                    //ProgOps.UpdateAmountInStock(lblApplesInventory, "Apples");
                    items[6].quantity -= 1;
                    total += items[6].cost;
                    break;
                }

            }
            //increases quantity and subtracts from total until quantity is back to original quantity
            if (rbDelete.Checked == true)
            {
                while (items[6].quantity != items[6].originalQty)
                {
                    items[6].quantity += 1;
                    total -= items[6].cost;
                    break;
                }
            }

            lblSteakInventory.Text = items[6].quantity.ToString();
            //add to the customers total
            lblTotal.Text = total.ToString("C");

            if (items[6].quantity == 0)
                MessageBox.Show("Steak is sold out!", "SOLD OUT");
        }

        private void pbxBread_Click(object sender, EventArgs e)
        {
            //decreases quantity and adds to total until quantity is 0
            if (rbAdd.Checked == true)
            {
                while (items[7].quantity > 0)
                {
                    //ProgOps.UpdateAmountInStock(lblApplesInventory, "Apples");
                    items[7].quantity -= 1;
                    total += items[7].cost;
                    break;
                }

            }
            //increases quantity and subtracts from total until quantity is back to original quantity
            if (rbDelete.Checked == true)
            {
                while (items[7].quantity != items[7].originalQty)
                {
                    items[7].quantity += 1;
                    total -= items[7].cost;
                    break;
                }
            }

            lblBreadInventory.Text = items[7].quantity.ToString();
            //add to the customers total
            lblTotal.Text = total.ToString("C");

            if (items[7].quantity == 0)
                MessageBox.Show("Bread is sold out!", "SOLD OUT");
        }

        private void pbxMilk_Click(object sender, EventArgs e)
        {
            //decreases quantity and adds to total until quantity is 0
            if (rbAdd.Checked == true)
            {
                while (items[8].quantity > 0)
                {
                    //ProgOps.UpdateAmountInStock(lblApplesInventory, "Apples");
                    items[8].quantity -= 1;
                    total += items[8].cost;
                    break;
                }

            }
            //increases quantity and subtracts from total until quantity is back to original quantity
            if (rbDelete.Checked == true)
            {
                while (items[8].quantity != items[8].originalQty)
                {
                    items[8].quantity += 1;
                    total -= items[8].cost;
                    break;
                }
            }

            lblMilkInventory.Text = items[8].quantity.ToString();
            //add to the customers total
            lblTotal.Text = total.ToString("C");

            if (items[8].quantity == 0)
                MessageBox.Show("Milk is sold out!", "SOLD OUT");
        }

        private void pbxChicken_Click(object sender, EventArgs e)
        {
            //decreases quantity and adds to total until quantity is 0
            if (rbAdd.Checked == true)
            {
                while (items[9].quantity > 0)
                {
                    //ProgOps.UpdateAmountInStock(lblApplesInventory, "Apples");
                    items[9].quantity -= 1;
                    total += items[9].cost;
                    break;
                }

            }
            //increases quantity and subtracts from total until quantity is back to original quantity
            if (rbDelete.Checked == true)
            {
                while (items[9].quantity != items[9].originalQty)
                {
                    items[9].quantity += 1;
                    total -= items[9].cost;
                    break;
                }
            }

            lblChickenInventory.Text = items[9].quantity.ToString();
            //add to the customers total
            lblTotal.Text = total.ToString("C");

            if (items[9].quantity == 0)
                MessageBox.Show("Chicken is sold out!", "SOLD OUT");
        }
        private void btnDeals_Click(object sender, EventArgs e)
        {

            MessageBox.Show("Here are a list of our daily coupons for our valued customers:" +
                "\n\nApply these codes when you checkout" +
                "\n\n20% off your total when you purchase $20 or more,\nuse code 20OFF" +
                "\n\n15% off your total when you purchase $15 or more,\nuse code 15OFF" +
                "\n\n10% off your total when you purchase $10 or more,\nuse code 10OFF" +
                "\n\n5% off your total when you purchase $5 or more,\nuse code 5OFF" +
                "\n\n***only one coupon per purchase", "DAILY DEALS", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void lblTotal_Click(object sender, EventArgs e)
        {

        }

        private void frmCustomers_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        
    }
    
    
}
