﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Group1_CSP
{
    public partial class frmCheckout : Form
    {
        public frmCheckout()
        {
            InitializeComponent();
        }

        private void frmCheckout_Load(object sender, EventArgs e)
        {
            //populate label with customer's total
            lblTotal.Text = frmCustomers.total.ToString("C2");

            //populate dgv with customer's order
            dgvOrder.DataSource = frmCustomers._orderForm;

        }

        private void btnCoupon_Click(object sender, EventArgs e)
        {
            double discount = 0;
            double total = frmCustomers.total;
            string coupon = "";

            coupon = tbxCoupon.Text.ToUpper().Trim();

            //deduction coupon discount based on customer's total
            //and if they enter the correct coupon code
            if (total >= 20.00 && coupon == "20OFF")
            {
                discount = total * .20;
                total -= discount;
                lblTotal.Text = total.ToString("C2");

                //disable button after one coupon code is applied
                btnCoupon.Enabled = false;
            }
            else if(total >= 15.00 && coupon == "15OFF")
            {
                discount = total * .15;
                total -= discount;
                lblTotal.Text = total.ToString("C2");

                //disable button after one coupon code is applied
                btnCoupon.Enabled = false;
            }
            else if (total >= 10.00 && coupon == "10OFF")
            {
                discount = total * .10;
                total -= discount;
                lblTotal.Text = total.ToString("C2");

                //disable button after one coupon code is applied
                btnCoupon.Enabled = false;

            }
            else if (total >= 5.00 && coupon == "5OFF")
            {
                discount = total * .05;
                total -= discount;
                lblTotal.Text = total.ToString("C2");

                //disable button after one coupon code is applied
                btnCoupon.Enabled = false;
            }
            else
            {
                MessageBox.Show("Your coupon is invalid", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            
        }

        private void btnPymnt_Click(object sender, EventArgs e)
        {
            string name, card, exp, cvv;

            name = tbxName.Text;
            card = tbxCard.Text;
        }

        private void tbxCard_KeyPress(object sender, KeyPressEventArgs e)
        {
            //accepts only numbers and backspace
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || (int)e.KeyChar == 8)
            {
                //acceptable keystrokes
                e.Handled = false;

            }
            else if ((int)e.KeyChar == 13)
            {
                tbxCard.Focus();
            }
            else
            {
                //plays beep when incorrect key is pressed
                e.Handled = true;
                SystemSounds.Beep.Play();
            }
        }

        private void tbxCVV_KeyPress(object sender, KeyPressEventArgs e)
        {
            //accepts only numbers and backspace
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || (int)e.KeyChar == 8)
            {
                //acceptable keystrokes
                e.Handled = false;

            }
            else if ((int)e.KeyChar == 13)
            {
                tbxCard.Focus();
            }
            else
            {
                //plays beep when incorrect key is pressed
                e.Handled = true;
                SystemSounds.Beep.Play();
            }
        }

        private void tbxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            //accepts only letter, backspace, and spaces
            if (char.IsLetter(e.KeyChar) || (int)e.KeyChar == 8 || char.IsWhiteSpace(e.KeyChar))
            {
                //acceptable keystrokes
                e.Handled = false;
            }
            else
            {
                //plays beep when incorrect key is pressed
                e.Handled = true;
                SystemSounds.Beep.Play();
            }
        }

        private void tbxMonth_KeyPress(object sender, KeyPressEventArgs e)
        {
            //accepts only numbers and backspace
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || (int)e.KeyChar == 8)
            {
                //acceptable keystrokes
                e.Handled = false;

            }
            else if ((int)e.KeyChar == 13)
            {
                tbxCard.Focus();
            }
            else
            {
                //plays beep when incorrect key is pressed
                e.Handled = true;
                SystemSounds.Beep.Play();
            }
        }

        private void tbxYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            //accepts only numbers and backspace
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || (int)e.KeyChar == 8)
            {
                //acceptable keystrokes
                e.Handled = false;

            }
            else if ((int)e.KeyChar == 13)
            {
                tbxCard.Focus();
            }
            else
            {
                //plays beep when incorrect key is pressed
                e.Handled = true;
                SystemSounds.Beep.Play();
            }
        }
    }
}
