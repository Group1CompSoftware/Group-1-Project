﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1_CSP
{
    public partial class frmUpdateEmployee : Form
    {
        public frmUpdateEmployee()
        {
            InitializeComponent();
        }

        private void frmUpdateEmployee_Load(object sender, EventArgs e)
        {
            ProgOps.ManagersQuery(dgvEmployeesTable, "Employees");
            for (int i = 0; i < dgvEmployeesTable.Rows.Count - 1; i++)
            {
                cbxEmployeeNames.Items.Add(dgvEmployeesTable.Rows[i].Cells[2].Value.ToString());
            }
        }

        private void cbxProductNames_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < dgvEmployeesTable.Columns.Count - 1; i++)
            {
                cbxColumnName.Items.Add(dgvEmployeesTable.Columns[i].Name.ToString());
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            string condition = "EmployeeName = '" + cbxEmployeeNames.Text.ToString() + "'";
            ProgOps.ManagersUpdate("Employees", cbxColumnName.Text.ToString(), tbxNewValue.Text.ToString(), condition);
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
