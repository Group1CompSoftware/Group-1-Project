﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1_CSP
{
    public partial class frmRemoveProduct : Form
    {
        public frmRemoveProduct()
        {
            InitializeComponent();
        }

        private void frmRemoveProduct_Load(object sender, EventArgs e)
        {
            ProgOps.ManagersQuery(dgvNameHolder, "Products");
            for(int i = 0; i < dgvNameHolder.Rows.Count - 1; i++)
            {
                cbxProducts.Items.Add(dgvNameHolder.Rows[i].Cells[1].Value.ToString());
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            ProgOps.ManagersDelete("Products", "ProductName = '" + cbxProducts.SelectedItem.ToString() + "'");
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
