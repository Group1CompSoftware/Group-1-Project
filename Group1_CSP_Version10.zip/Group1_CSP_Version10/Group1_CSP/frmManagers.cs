﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1_CSP
{
    public partial class frmManagers : Form
    {
        public frmManagers()
        {
            InitializeComponent();
        }

        private void frmManagers_Load(object sender, EventArgs e)
        {

        }

        private void frmManagers_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void btnDisplayProducts_Click(object sender, EventArgs e)
        {
            ProgOps.ManagersQuery(dgvManagersView, "Products");
        }

        private void btnDisplayEmployees_Click(object sender, EventArgs e)
        {
            ProgOps.ManagersQuery(dgvManagersView, "Employees");
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            frmAddProduct addproduct = new frmAddProduct();
            addproduct.ShowDialog();
        }

        private void btnRemoveProduct_Click(object sender, EventArgs e)
        {
            frmRemoveProduct removeProduct = new frmRemoveProduct();
            removeProduct.ShowDialog();
        }

        private void btnChangeProduct_Click(object sender, EventArgs e)
        {
            frmUpdateProduct updateProduct = new frmUpdateProduct();
            updateProduct.ShowDialog();
        }

        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            frmAddEmployee addEmployee = new frmAddEmployee();
            addEmployee.ShowDialog();
        }

        private void btnRemoveEmployee_Click(object sender, EventArgs e)
        {
            frmRemoveEmployee removeEmployee = new frmRemoveEmployee();
            removeEmployee.ShowDialog();
        }

        private void btnChangeEmployee_Click(object sender, EventArgs e)
        {
            frmUpdateEmployee updateEmployee = new frmUpdateEmployee();
            updateEmployee.ShowDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
