﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1_CSP
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (rdbCustomer.Checked == true)
            {
                //add if statement to see if login exists
            }
            else if (rdbEmployee.Checked == true)
            {
                //add if statement to see if login exists
            }
            else if (rdbManager.Checked == true)
            {
                //add if statement to see if login exists
                frmManagers managers = new frmManagers();
                managers.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a user type", "Error");
            }
        }
    }
}
