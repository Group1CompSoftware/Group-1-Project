﻿namespace Group1_CSP
{
    partial class frmCustomers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblChickenPrice = new System.Windows.Forms.Label();
            this.lblBananasPrice = new System.Windows.Forms.Label();
            this.lblGrapesPrice = new System.Windows.Forms.Label();
            this.lblCarrotsPrice = new System.Windows.Forms.Label();
            this.lblOrangesPrice = new System.Windows.Forms.Label();
            this.lblEggsPrice = new System.Windows.Forms.Label();
            this.lblSteakPrice = new System.Windows.Forms.Label();
            this.lblBreadPrice = new System.Windows.Forms.Label();
            this.lblMilkPrice = new System.Windows.Forms.Label();
            this.lblApplesPrice = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblApplesInventory = new System.Windows.Forms.Label();
            this.lblChickenInventory = new System.Windows.Forms.Label();
            this.lblMilkInventory = new System.Windows.Forms.Label();
            this.lblBreadInventory = new System.Windows.Forms.Label();
            this.lblSteakInventory = new System.Windows.Forms.Label();
            this.lblEggsInventory = new System.Windows.Forms.Label();
            this.lblOrangesInventory = new System.Windows.Forms.Label();
            this.lblCarrotsInventory = new System.Windows.Forms.Label();
            this.lblGrapesInventory = new System.Windows.Forms.Label();
            this.lblBananaInventory = new System.Windows.Forms.Label();
            this.btnCheckout = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.pbxChicken = new System.Windows.Forms.PictureBox();
            this.pbxBananas = new System.Windows.Forms.PictureBox();
            this.pbxGrapes = new System.Windows.Forms.PictureBox();
            this.pbxCarrots = new System.Windows.Forms.PictureBox();
            this.pbxOranges = new System.Windows.Forms.PictureBox();
            this.pbxEggs = new System.Windows.Forms.PictureBox();
            this.pbxSteak = new System.Windows.Forms.PictureBox();
            this.pbxMilk = new System.Windows.Forms.PictureBox();
            this.pbxBread = new System.Windows.Forms.PictureBox();
            this.pbxApples = new System.Windows.Forms.PictureBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.gbxAddOrDelete = new System.Windows.Forms.GroupBox();
            this.rbAdd = new System.Windows.Forms.RadioButton();
            this.rbDelete = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChicken)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBananas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrapes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCarrots)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOranges)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxEggs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSteak)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMilk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBread)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxApples)).BeginInit();
            this.gbxAddOrDelete.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblChickenPrice
            // 
            this.lblChickenPrice.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblChickenPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChickenPrice.ForeColor = System.Drawing.Color.White;
            this.lblChickenPrice.Location = new System.Drawing.Point(600, 256);
            this.lblChickenPrice.Name = "lblChickenPrice";
            this.lblChickenPrice.Size = new System.Drawing.Size(49, 20);
            this.lblChickenPrice.TabIndex = 61;
            // 
            // lblBananasPrice
            // 
            this.lblBananasPrice.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBananasPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBananasPrice.ForeColor = System.Drawing.Color.White;
            this.lblBananasPrice.Location = new System.Drawing.Point(165, 67);
            this.lblBananasPrice.Name = "lblBananasPrice";
            this.lblBananasPrice.Size = new System.Drawing.Size(49, 20);
            this.lblBananasPrice.TabIndex = 60;
            // 
            // lblGrapesPrice
            // 
            this.lblGrapesPrice.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblGrapesPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrapesPrice.ForeColor = System.Drawing.Color.White;
            this.lblGrapesPrice.Location = new System.Drawing.Point(310, 67);
            this.lblGrapesPrice.Name = "lblGrapesPrice";
            this.lblGrapesPrice.Size = new System.Drawing.Size(49, 20);
            this.lblGrapesPrice.TabIndex = 59;
            // 
            // lblCarrotsPrice
            // 
            this.lblCarrotsPrice.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblCarrotsPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarrotsPrice.ForeColor = System.Drawing.Color.White;
            this.lblCarrotsPrice.Location = new System.Drawing.Point(455, 67);
            this.lblCarrotsPrice.Name = "lblCarrotsPrice";
            this.lblCarrotsPrice.Size = new System.Drawing.Size(49, 20);
            this.lblCarrotsPrice.TabIndex = 58;
            // 
            // lblOrangesPrice
            // 
            this.lblOrangesPrice.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblOrangesPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrangesPrice.ForeColor = System.Drawing.Color.White;
            this.lblOrangesPrice.Location = new System.Drawing.Point(600, 67);
            this.lblOrangesPrice.Name = "lblOrangesPrice";
            this.lblOrangesPrice.Size = new System.Drawing.Size(49, 20);
            this.lblOrangesPrice.TabIndex = 57;
            // 
            // lblEggsPrice
            // 
            this.lblEggsPrice.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblEggsPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEggsPrice.ForeColor = System.Drawing.Color.White;
            this.lblEggsPrice.Location = new System.Drawing.Point(24, 256);
            this.lblEggsPrice.Name = "lblEggsPrice";
            this.lblEggsPrice.Size = new System.Drawing.Size(49, 20);
            this.lblEggsPrice.TabIndex = 56;
            // 
            // lblSteakPrice
            // 
            this.lblSteakPrice.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblSteakPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSteakPrice.ForeColor = System.Drawing.Color.White;
            this.lblSteakPrice.Location = new System.Drawing.Point(165, 256);
            this.lblSteakPrice.Name = "lblSteakPrice";
            this.lblSteakPrice.Size = new System.Drawing.Size(49, 20);
            this.lblSteakPrice.TabIndex = 55;
            // 
            // lblBreadPrice
            // 
            this.lblBreadPrice.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBreadPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBreadPrice.ForeColor = System.Drawing.Color.White;
            this.lblBreadPrice.Location = new System.Drawing.Point(310, 256);
            this.lblBreadPrice.Name = "lblBreadPrice";
            this.lblBreadPrice.Size = new System.Drawing.Size(49, 20);
            this.lblBreadPrice.TabIndex = 54;
            // 
            // lblMilkPrice
            // 
            this.lblMilkPrice.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblMilkPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMilkPrice.ForeColor = System.Drawing.Color.White;
            this.lblMilkPrice.Location = new System.Drawing.Point(455, 256);
            this.lblMilkPrice.Name = "lblMilkPrice";
            this.lblMilkPrice.Size = new System.Drawing.Size(49, 20);
            this.lblMilkPrice.TabIndex = 53;
            // 
            // lblApplesPrice
            // 
            this.lblApplesPrice.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblApplesPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApplesPrice.ForeColor = System.Drawing.Color.White;
            this.lblApplesPrice.Location = new System.Drawing.Point(25, 67);
            this.lblApplesPrice.Name = "lblApplesPrice";
            this.lblApplesPrice.Size = new System.Drawing.Size(49, 20);
            this.lblApplesPrice.TabIndex = 52;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(500, 232);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 24);
            this.label10.TabIndex = 51;
            this.label10.Text = "Milk";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(633, 229);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 24);
            this.label9.TabIndex = 50;
            this.label9.Text = "Chicken";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(483, 40);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 24);
            this.label8.TabIndex = 49;
            this.label8.Text = "Carrots";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(629, 40);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 24);
            this.label7.TabIndex = 48;
            this.label7.Text = "Oranges";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(68, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 24);
            this.label6.TabIndex = 47;
            this.label6.Text = "Eggs";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(203, 229);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 24);
            this.label5.TabIndex = 46;
            this.label5.Text = "Steak";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(351, 229);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 24);
            this.label4.TabIndex = 45;
            this.label4.Text = "Bread";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(340, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 24);
            this.label3.TabIndex = 44;
            this.label3.Text = "Grapes";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(186, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 24);
            this.label2.TabIndex = 43;
            this.label2.Text = "Bananas";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(53, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 24);
            this.label1.TabIndex = 42;
            this.label1.Text = "Apples";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblApplesInventory
            // 
            this.lblApplesInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblApplesInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApplesInventory.ForeColor = System.Drawing.Color.White;
            this.lblApplesInventory.Location = new System.Drawing.Point(131, 184);
            this.lblApplesInventory.Name = "lblApplesInventory";
            this.lblApplesInventory.Size = new System.Drawing.Size(28, 23);
            this.lblApplesInventory.TabIndex = 62;
            this.lblApplesInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblChickenInventory
            // 
            this.lblChickenInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblChickenInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChickenInventory.ForeColor = System.Drawing.Color.White;
            this.lblChickenInventory.Location = new System.Drawing.Point(711, 373);
            this.lblChickenInventory.Name = "lblChickenInventory";
            this.lblChickenInventory.Size = new System.Drawing.Size(28, 23);
            this.lblChickenInventory.TabIndex = 63;
            this.lblChickenInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMilkInventory
            // 
            this.lblMilkInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblMilkInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMilkInventory.ForeColor = System.Drawing.Color.White;
            this.lblMilkInventory.Location = new System.Drawing.Point(566, 373);
            this.lblMilkInventory.Name = "lblMilkInventory";
            this.lblMilkInventory.Size = new System.Drawing.Size(28, 23);
            this.lblMilkInventory.TabIndex = 64;
            this.lblMilkInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBreadInventory
            // 
            this.lblBreadInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBreadInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBreadInventory.ForeColor = System.Drawing.Color.White;
            this.lblBreadInventory.Location = new System.Drawing.Point(421, 373);
            this.lblBreadInventory.Name = "lblBreadInventory";
            this.lblBreadInventory.Size = new System.Drawing.Size(28, 23);
            this.lblBreadInventory.TabIndex = 65;
            this.lblBreadInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSteakInventory
            // 
            this.lblSteakInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblSteakInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSteakInventory.ForeColor = System.Drawing.Color.White;
            this.lblSteakInventory.Location = new System.Drawing.Point(276, 373);
            this.lblSteakInventory.Name = "lblSteakInventory";
            this.lblSteakInventory.Size = new System.Drawing.Size(28, 23);
            this.lblSteakInventory.TabIndex = 66;
            this.lblSteakInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEggsInventory
            // 
            this.lblEggsInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblEggsInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEggsInventory.ForeColor = System.Drawing.Color.White;
            this.lblEggsInventory.Location = new System.Drawing.Point(131, 373);
            this.lblEggsInventory.Name = "lblEggsInventory";
            this.lblEggsInventory.Size = new System.Drawing.Size(28, 23);
            this.lblEggsInventory.TabIndex = 67;
            this.lblEggsInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOrangesInventory
            // 
            this.lblOrangesInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblOrangesInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrangesInventory.ForeColor = System.Drawing.Color.White;
            this.lblOrangesInventory.Location = new System.Drawing.Point(711, 184);
            this.lblOrangesInventory.Name = "lblOrangesInventory";
            this.lblOrangesInventory.Size = new System.Drawing.Size(28, 23);
            this.lblOrangesInventory.TabIndex = 68;
            this.lblOrangesInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCarrotsInventory
            // 
            this.lblCarrotsInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblCarrotsInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarrotsInventory.ForeColor = System.Drawing.Color.White;
            this.lblCarrotsInventory.Location = new System.Drawing.Point(566, 184);
            this.lblCarrotsInventory.Name = "lblCarrotsInventory";
            this.lblCarrotsInventory.Size = new System.Drawing.Size(28, 23);
            this.lblCarrotsInventory.TabIndex = 69;
            this.lblCarrotsInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGrapesInventory
            // 
            this.lblGrapesInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblGrapesInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrapesInventory.ForeColor = System.Drawing.Color.White;
            this.lblGrapesInventory.Location = new System.Drawing.Point(421, 184);
            this.lblGrapesInventory.Name = "lblGrapesInventory";
            this.lblGrapesInventory.Size = new System.Drawing.Size(28, 23);
            this.lblGrapesInventory.TabIndex = 70;
            this.lblGrapesInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBananaInventory
            // 
            this.lblBananaInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBananaInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBananaInventory.ForeColor = System.Drawing.Color.White;
            this.lblBananaInventory.Location = new System.Drawing.Point(276, 184);
            this.lblBananaInventory.Name = "lblBananaInventory";
            this.lblBananaInventory.Size = new System.Drawing.Size(28, 23);
            this.lblBananaInventory.TabIndex = 71;
            this.lblBananaInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnCheckout
            // 
            this.btnCheckout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckout.Location = new System.Drawing.Point(169, 567);
            this.btnCheckout.Name = "btnCheckout";
            this.btnCheckout.Size = new System.Drawing.Size(97, 39);
            this.btnCheckout.TabIndex = 72;
            this.btnCheckout.Text = "&Checkout";
            this.btnCheckout.UseVisualStyleBackColor = true;
            this.btnCheckout.Click += new System.EventHandler(this.btnCheckout_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(487, 567);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(97, 39);
            this.btnExit.TabIndex = 73;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(26, 414);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(377, 18);
            this.label21.TabIndex = 74;
            this.label21.Text = "Click an item to add to or delete from your shopping cart\r\n";
            // 
            // pbxChicken
            // 
            this.pbxChicken.Image = global::Group1_CSP.Properties.Resources.chicken5;
            this.pbxChicken.Location = new System.Drawing.Point(604, 256);
            this.pbxChicken.Name = "pbxChicken";
            this.pbxChicken.Size = new System.Drawing.Size(135, 140);
            this.pbxChicken.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxChicken.TabIndex = 41;
            this.pbxChicken.TabStop = false;
            this.pbxChicken.Click += new System.EventHandler(this.pbxChicken_Click);
            // 
            // pbxBananas
            // 
            this.pbxBananas.Image = global::Group1_CSP.Properties.Resources.bananas;
            this.pbxBananas.Location = new System.Drawing.Point(169, 67);
            this.pbxBananas.Name = "pbxBananas";
            this.pbxBananas.Size = new System.Drawing.Size(135, 140);
            this.pbxBananas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxBananas.TabIndex = 40;
            this.pbxBananas.TabStop = false;
            this.pbxBananas.Click += new System.EventHandler(this.pbxBananas_Click);
            // 
            // pbxGrapes
            // 
            this.pbxGrapes.Image = global::Group1_CSP.Properties.Resources.grapes;
            this.pbxGrapes.Location = new System.Drawing.Point(314, 67);
            this.pbxGrapes.Name = "pbxGrapes";
            this.pbxGrapes.Size = new System.Drawing.Size(135, 140);
            this.pbxGrapes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxGrapes.TabIndex = 39;
            this.pbxGrapes.TabStop = false;
            this.pbxGrapes.Click += new System.EventHandler(this.pbxGrapes_Click);
            // 
            // pbxCarrots
            // 
            this.pbxCarrots.Image = global::Group1_CSP.Properties.Resources.carrots;
            this.pbxCarrots.Location = new System.Drawing.Point(459, 67);
            this.pbxCarrots.Name = "pbxCarrots";
            this.pbxCarrots.Size = new System.Drawing.Size(135, 140);
            this.pbxCarrots.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxCarrots.TabIndex = 38;
            this.pbxCarrots.TabStop = false;
            this.pbxCarrots.Click += new System.EventHandler(this.pbxCarrots_Click);
            // 
            // pbxOranges
            // 
            this.pbxOranges.Image = global::Group1_CSP.Properties.Resources.oranges;
            this.pbxOranges.Location = new System.Drawing.Point(604, 67);
            this.pbxOranges.Name = "pbxOranges";
            this.pbxOranges.Size = new System.Drawing.Size(135, 140);
            this.pbxOranges.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxOranges.TabIndex = 37;
            this.pbxOranges.TabStop = false;
            this.pbxOranges.Click += new System.EventHandler(this.pbxOranges_Click);
            // 
            // pbxEggs
            // 
            this.pbxEggs.Image = global::Group1_CSP.Properties.Resources.eggs;
            this.pbxEggs.Location = new System.Drawing.Point(24, 256);
            this.pbxEggs.Name = "pbxEggs";
            this.pbxEggs.Size = new System.Drawing.Size(135, 140);
            this.pbxEggs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxEggs.TabIndex = 36;
            this.pbxEggs.TabStop = false;
            this.pbxEggs.Click += new System.EventHandler(this.pbxEggs_Click);
            // 
            // pbxSteak
            // 
            this.pbxSteak.Image = global::Group1_CSP.Properties.Resources.steak;
            this.pbxSteak.Location = new System.Drawing.Point(169, 256);
            this.pbxSteak.Name = "pbxSteak";
            this.pbxSteak.Size = new System.Drawing.Size(135, 140);
            this.pbxSteak.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxSteak.TabIndex = 35;
            this.pbxSteak.TabStop = false;
            this.pbxSteak.Click += new System.EventHandler(this.pbxSteak_Click);
            // 
            // pbxMilk
            // 
            this.pbxMilk.Image = global::Group1_CSP.Properties.Resources.milk;
            this.pbxMilk.Location = new System.Drawing.Point(459, 256);
            this.pbxMilk.Name = "pbxMilk";
            this.pbxMilk.Size = new System.Drawing.Size(135, 140);
            this.pbxMilk.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxMilk.TabIndex = 34;
            this.pbxMilk.TabStop = false;
            this.pbxMilk.Click += new System.EventHandler(this.pbxMilk_Click);
            // 
            // pbxBread
            // 
            this.pbxBread.Image = global::Group1_CSP.Properties.Resources.bread1;
            this.pbxBread.Location = new System.Drawing.Point(314, 256);
            this.pbxBread.Name = "pbxBread";
            this.pbxBread.Size = new System.Drawing.Size(135, 140);
            this.pbxBread.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxBread.TabIndex = 33;
            this.pbxBread.TabStop = false;
            this.pbxBread.Click += new System.EventHandler(this.pbxBread_Click);
            // 
            // pbxApples
            // 
            this.pbxApples.ErrorImage = null;
            this.pbxApples.Image = global::Group1_CSP.Properties.Resources.apples2;
            this.pbxApples.InitialImage = null;
            this.pbxApples.Location = new System.Drawing.Point(24, 67);
            this.pbxApples.Name = "pbxApples";
            this.pbxApples.Size = new System.Drawing.Size(135, 140);
            this.pbxApples.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxApples.TabIndex = 32;
            this.pbxApples.TabStop = false;
            this.pbxApples.Click += new System.EventHandler(this.pbxApples_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.BackColor = System.Drawing.Color.AliceBlue;
            this.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(646, 501);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(93, 37);
            this.lblTotal.TabIndex = 75;
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTotal.Click += new System.EventHandler(this.lblTotal_Click);
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.MidnightBlue;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(587, 501);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 37);
            this.label22.TabIndex = 76;
            this.label22.Text = "Total: ";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbxAddOrDelete
            // 
            this.gbxAddOrDelete.Controls.Add(this.rbDelete);
            this.gbxAddOrDelete.Controls.Add(this.rbAdd);
            this.gbxAddOrDelete.Location = new System.Drawing.Point(29, 448);
            this.gbxAddOrDelete.Name = "gbxAddOrDelete";
            this.gbxAddOrDelete.Size = new System.Drawing.Size(201, 90);
            this.gbxAddOrDelete.TabIndex = 77;
            this.gbxAddOrDelete.TabStop = false;
            // 
            // rbAdd
            // 
            this.rbAdd.AutoSize = true;
            this.rbAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAdd.ForeColor = System.Drawing.Color.White;
            this.rbAdd.Location = new System.Drawing.Point(28, 19);
            this.rbAdd.Name = "rbAdd";
            this.rbAdd.Size = new System.Drawing.Size(108, 24);
            this.rbAdd.TabIndex = 0;
            this.rbAdd.TabStop = true;
            this.rbAdd.Text = "Add to Cart";
            this.rbAdd.UseVisualStyleBackColor = true;
            // 
            // rbDelete
            // 
            this.rbDelete.AutoSize = true;
            this.rbDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbDelete.ForeColor = System.Drawing.Color.White;
            this.rbDelete.Location = new System.Drawing.Point(28, 53);
            this.rbDelete.Name = "rbDelete";
            this.rbDelete.Size = new System.Drawing.Size(144, 24);
            this.rbDelete.TabIndex = 1;
            this.rbDelete.TabStop = true;
            this.rbDelete.Text = "Delete from Cart";
            this.rbDelete.UseVisualStyleBackColor = true;
            // 
            // frmCustomers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(763, 614);
            this.Controls.Add(this.gbxAddOrDelete);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCheckout);
            this.Controls.Add(this.lblBananaInventory);
            this.Controls.Add(this.lblGrapesInventory);
            this.Controls.Add(this.lblCarrotsInventory);
            this.Controls.Add(this.lblOrangesInventory);
            this.Controls.Add(this.lblEggsInventory);
            this.Controls.Add(this.lblSteakInventory);
            this.Controls.Add(this.lblBreadInventory);
            this.Controls.Add(this.lblMilkInventory);
            this.Controls.Add(this.lblChickenInventory);
            this.Controls.Add(this.lblApplesInventory);
            this.Controls.Add(this.lblChickenPrice);
            this.Controls.Add(this.lblBananasPrice);
            this.Controls.Add(this.lblGrapesPrice);
            this.Controls.Add(this.lblCarrotsPrice);
            this.Controls.Add(this.lblOrangesPrice);
            this.Controls.Add(this.lblEggsPrice);
            this.Controls.Add(this.lblSteakPrice);
            this.Controls.Add(this.lblBreadPrice);
            this.Controls.Add(this.lblMilkPrice);
            this.Controls.Add(this.lblApplesPrice);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbxChicken);
            this.Controls.Add(this.pbxBananas);
            this.Controls.Add(this.pbxGrapes);
            this.Controls.Add(this.pbxCarrots);
            this.Controls.Add(this.pbxOranges);
            this.Controls.Add(this.pbxEggs);
            this.Controls.Add(this.pbxSteak);
            this.Controls.Add(this.pbxMilk);
            this.Controls.Add(this.pbxBread);
            this.Controls.Add(this.pbxApples);
            this.Name = "frmCustomers";
            this.Text = "Customers";
            this.Load += new System.EventHandler(this.frmCustomers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxChicken)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBananas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrapes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCarrots)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOranges)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxEggs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSteak)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMilk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBread)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxApples)).EndInit();
            this.gbxAddOrDelete.ResumeLayout(false);
            this.gbxAddOrDelete.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblChickenPrice;
        private System.Windows.Forms.Label lblBananasPrice;
        private System.Windows.Forms.Label lblGrapesPrice;
        private System.Windows.Forms.Label lblCarrotsPrice;
        private System.Windows.Forms.Label lblOrangesPrice;
        private System.Windows.Forms.Label lblEggsPrice;
        private System.Windows.Forms.Label lblSteakPrice;
        private System.Windows.Forms.Label lblBreadPrice;
        private System.Windows.Forms.Label lblMilkPrice;
        private System.Windows.Forms.Label lblApplesPrice;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbxChicken;
        private System.Windows.Forms.PictureBox pbxBananas;
        private System.Windows.Forms.PictureBox pbxGrapes;
        private System.Windows.Forms.PictureBox pbxCarrots;
        private System.Windows.Forms.PictureBox pbxOranges;
        private System.Windows.Forms.PictureBox pbxEggs;
        private System.Windows.Forms.PictureBox pbxSteak;
        private System.Windows.Forms.PictureBox pbxMilk;
        private System.Windows.Forms.PictureBox pbxBread;
        private System.Windows.Forms.PictureBox pbxApples;
        private System.Windows.Forms.Label lblApplesInventory;
        private System.Windows.Forms.Label lblChickenInventory;
        private System.Windows.Forms.Label lblMilkInventory;
        private System.Windows.Forms.Label lblBreadInventory;
        private System.Windows.Forms.Label lblSteakInventory;
        private System.Windows.Forms.Label lblEggsInventory;
        private System.Windows.Forms.Label lblOrangesInventory;
        private System.Windows.Forms.Label lblCarrotsInventory;
        private System.Windows.Forms.Label lblGrapesInventory;
        private System.Windows.Forms.Label lblBananaInventory;
        private System.Windows.Forms.Button btnCheckout;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox gbxAddOrDelete;
        private System.Windows.Forms.RadioButton rbDelete;
        private System.Windows.Forms.RadioButton rbAdd;
    }
}