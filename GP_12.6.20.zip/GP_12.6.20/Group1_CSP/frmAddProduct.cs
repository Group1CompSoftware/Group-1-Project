﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Group1_CSP
{
    public partial class frmAddProduct : Form
    {
        string imageLocation;

        public frmAddProduct()
        {
            InitializeComponent();
        }

        private void frmAddProduct_Load(object sender, EventArgs e)
        {

        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if(InputValidation.ValidateProductAdd(tbxProductID.Text, tbxProductName.Text, tbxProductPrice.Text, tbxImageID.Text, tbxAmountInStock.Text))
            {
                try
                {
                    byte[] imageBytes = null;
                    FileStream fileStream = new FileStream(imageLocation, FileMode.Open, FileAccess.Read);
                    BinaryReader binaryReader = new BinaryReader(fileStream);
                    imageBytes = binaryReader.ReadBytes((int)fileStream.Length);

                    ProgOps.ManagersInsert("Products", tbxProductID.Text, "'" + tbxProductName.Text + "'", tbxProductPrice.Text, tbxImageID.Text, tbxAmountInStock.Text, imageBytes);
                    this.Close();
                }
                catch(Exception ex)
                {
                    if(ex.Message.Contains("Path cannot be null."))
                    {
                        MessageBox.Show("An image must be selected.");
                    }
                    else
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Input invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSelectImage_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog OFD = new OpenFileDialog();
                OFD.Filter = "Image files (*.jpg, *.png)|*.jpg; *.png;";
                OFD.Title = "Select product image";
                if(OFD.ShowDialog() == DialogResult.OK)
                {
                    imageLocation = OFD.FileName.ToString();
                    pbxSelectedImage.ImageLocation = imageLocation;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
