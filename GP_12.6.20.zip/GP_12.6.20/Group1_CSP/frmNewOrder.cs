﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1_CSP
{
    public partial class frmNewOrder : Form
    {
        public frmNewOrder()
        {
            InitializeComponent();
        }

        private void frmNewOrder_Load(object sender, EventArgs e)
        {
            tbxOrderID.Text = ProgOps.GetNextID().ToString();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnInsertOrder_Click(object sender, EventArgs e)
        {
            int quantity;

            if(tbxCName.Text == "" || tbxEName.Text == "" || tbxPName.Text == "" || tbxQuantity.Text == "")
            {
                MessageBox.Show("All fields must be filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if(ProgOps.VerifyCustomer(tbxCName.Text))
                {
                    if(ProgOps.VerifyProduct(tbxPName.Text))
                    {
                        if(ProgOps.VerifyEmployee(tbxEName.Text))
                        {
                            if (int.TryParse(tbxQuantity.Text, out quantity))
                            {
                                if (ProgOps.VerifyQuantity(tbxPName.Text, quantity))
                                {
                                    ProgOps.InsertNewOrder(int.Parse(tbxOrderID.Text), ProgOps.RetrieveCID(tbxCName.Text), ProgOps.RetrievePID(tbxPName.Text), ProgOps.RetrieveEID(tbxEName.Text), quantity);
                                }
                                else
                                {
                                    MessageBox.Show("Not enough stock to fulfill order.", "Insufficient Stock", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }

                            }
                            else
                            {
                                MessageBox.Show("Quantity must be a numerical value.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Employee Name is invalid. Please verify spelling is correct.", "Invalid Employee", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Product Name is invalid. Please verify spelling is correct.", "Invalid Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Customer Name is invalid. Please verify spelling is correct.", "Invalid Customer", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
