﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1_CSP
{
    public partial class frmUpdateEmployee : Form
    {
        public frmUpdateEmployee()
        {
            InitializeComponent();
        }

        private void frmUpdateEmployee_Load(object sender, EventArgs e)
        {
            ProgOps.ManagersQuery(dgvEmployeesTable, "Employees");
            for (int i = 0; i < dgvEmployeesTable.Rows.Count - 1; i++)
            {
                cbxEmployeeNames.Items.Add(dgvEmployeesTable.Rows[i].Cells[2].Value.ToString());
            }
        }

        private void cbxProductNames_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < dgvEmployeesTable.Columns.Count - 1; i++)
            {
                cbxColumnName.Items.Add(dgvEmployeesTable.Columns[i].Name.ToString());
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            //Sees if value in first cbx is valid
            bool valid1 = false;
            for (int i = 0; i < cbxEmployeeNames.Items.Count; i++)
            {
                if (cbxEmployeeNames.Text == cbxEmployeeNames.Items[i].ToString())
                {
                    valid1 = true;
                }
            }

            //Sees if value in second cbx is valid
            bool valid2 = false;
            for (int i = 0; i < cbxColumnName.Items.Count; i++)
            {
                if (cbxColumnName.Text == cbxColumnName.Items[i].ToString())
                {
                    valid2 = true;
                }
            }

            //Sees if input is valid
            bool valid3 = InputValidation.ValidateEmployeeUpdate(cbxColumnName.Text.ToString(), tbxNewValue.Text.ToString());

            //If all are valid does the thing it needs to do; else sends error mmessage
            if (valid1 && valid2 && valid3)
            {
                int i = 0;
                string newValue;
                if (int.TryParse(tbxNewValue.Text.ToString(), out i))
                {
                    newValue = tbxNewValue.Text.ToString();
                }
                else
                {
                    newValue = "'" + tbxNewValue.Text.ToString() + "'";
                }

                string condition = "EmployeeName = '" + cbxEmployeeNames.Text.ToString() + "'";
                ProgOps.ManagersUpdate("Employees", cbxColumnName.Text.ToString(), newValue, condition);
                this.Close();
            }
            else
            {
                MessageBox.Show("Input invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
