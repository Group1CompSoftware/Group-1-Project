﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Group1_CSP
{
    public partial class frmCheckout : Form
    {
        public frmCheckout()
        {
            InitializeComponent();
        }
        private void frmCheckout_Load(object sender, EventArgs e)
        {
            //populate label with customer's total
            lblTotal.Text = frmCustomers.total.ToString("C2");

            //populate dgv with customer's order
            dgvOrder.DataSource = frmCustomers._orderForm;
        }


        //validate input for textboxes & label
        private bool ValidateData()
        {
            string message = "";
            bool valid = true;

            // Check for total 
            if (lblTotal.Text.Equals("$0.00"))
            {
                message += "You cannot make a payment of $0.00." + "\r\n";
                valid = false;
            }

            //check if any text boxes are empty
            if ((tbxName.Text.Equals("") || tbxCard.Text.Equals("") || tbxMonth.Text.Equals("") ||
                tbxYear.Text.Equals("") || tbxCVV.Text.Equals("")))
            {
                message += "You must enter data in all textboxes" + "\r\n";
                tbxName.Focus();
                valid = false;
            }
            else
            {
                //check card number length
                int cardLength = tbxCard.Text.Length;
                if (cardLength != 16)
                {
                    message += "Your card number must contain 16 digits" + "\r\n";
                    tbxCard.Focus();
                    valid = false;
                }

                //month must between 01-12
                int month = Convert.ToInt32(tbxMonth.Text);
                if (month > 12 || month < 01)
                {
                    message += "Month must be between 01 and 12" + "\r\n";
                    tbxMonth.Focus();
                    valid = false;
                }
                //check month length
                int monthLength = tbxMonth.Text.Length;
                if (monthLength != 2)
                {
                    message += "Month must be 2 digits (MM)" + "\r\n";
                    tbxMonth.Focus();
                    valid = false;
                }

                //year must between > 12/2020
                int year = Convert.ToInt32(tbxYear.Text);
                if (year <= 20)
                {
                    message += "Year must be later than 12/2020" + "\r\n";
                    tbxYear.Focus();
                    valid = false;
                }
                //check year length
                int yearLength = tbxYear.Text.Length;
                if (yearLength != 2)
                {
                    message += "Year must be 2 digits (YY)" + "\r\n";
                    tbxYear.Focus();
                    valid = false;
                }

                //check cvv number length
                int cvvLength = tbxCVV.Text.Length;
                if (cvvLength != 3)
                {
                    message = "Your CVV must contain 3 digits" + "\r\n";
                    tbxCVV.Focus();
                    valid = false;
                }


            }

            if (!valid)
            {
                MessageBox.Show(message, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return (valid);
        }


        private void btnCoupon_Click(object sender, EventArgs e)
        {
            double discount = 0;
            double total = frmCustomers.total;
            string coupon = "";

            coupon = tbxCoupon.Text.ToUpper().Trim();

            //deduction coupon discount based on customer's total
            //and if they enter the correct coupon code
            if (total >= 20.00 && coupon == "20OFF")
            {
                discount = total * .20;
                total -= discount;
                lblTotal.Text = total.ToString("C2");

                //disable button after one coupon code is applied
                btnCoupon.Enabled = false;
            }
            else if (total >= 15.00 && coupon == "15OFF")
            {
                discount = total * .15;
                total -= discount;
                lblTotal.Text = total.ToString("C2");

                //disable button after one coupon code is applied
                btnCoupon.Enabled = false;
            }
            else if (total >= 10.00 && coupon == "10OFF")
            {
                discount = total * .10;
                total -= discount;
                lblTotal.Text = total.ToString("C2");

                //disable button after one coupon code is applied
                btnCoupon.Enabled = false;

            }
            else if (total >= 5.00 && coupon == "5OFF")
            {
                discount = total * .05;
                total -= discount;
                lblTotal.Text = total.ToString("C2");

                //disable button after one coupon code is applied
                btnCoupon.Enabled = false;
            }
            else
            {
                MessageBox.Show("Your coupon is invalid", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbxCoupon.Text = "";
                tbxCoupon.Focus();
            }
        }

        private void btnPymnt_Click(object sender, EventArgs e)
        {
            //if data is valid payment is successful
            if (ValidateData())
            {
                MessageBox.Show("Payment successful! Thank you for shopping with us!", "Payment Confirmation");
            }
        }


        private void tbxCard_KeyPress(object sender, KeyPressEventArgs e)
        {
            //accepts only numbers and backspace
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || (int)e.KeyChar == 8)
            {
                //acceptable keystrokes
                e.Handled = false;

            }
            else if ((int)e.KeyChar == 13)
            {
                tbxCard.Focus();
            }
            else
            {
                //plays beep when incorrect key is pressed
                e.Handled = true;
                SystemSounds.Beep.Play();
            }
        }

        private void tbxCVV_KeyPress(object sender, KeyPressEventArgs e)
        {
            //accepts only numbers and backspace
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || (int)e.KeyChar == 8)
            {
                //acceptable keystrokes
                e.Handled = false;

            }
            else if ((int)e.KeyChar == 13)
            {
                tbxCard.Focus();
            }
            else
            {
                //plays beep when incorrect key is pressed
                e.Handled = true;
                SystemSounds.Beep.Play();
            }
        }

        private void tbxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            //accepts only letter, backspace, and spaces
            if (char.IsLetter(e.KeyChar) || (int)e.KeyChar == 8 || char.IsWhiteSpace(e.KeyChar))
            {
                //acceptable keystrokes
                e.Handled = false;
            }
            else
            {
                //plays beep when incorrect key is pressed
                e.Handled = true;
                SystemSounds.Beep.Play();
            }
        }

        private void tbxMonth_KeyPress(object sender, KeyPressEventArgs e)
        {
            //accepts only numbers and backspace
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || (int)e.KeyChar == 8)
            {
                //acceptable keystrokes
                e.Handled = false;

            }
            else if ((int)e.KeyChar == 13)
            {
                tbxCard.Focus();
            }
            else
            {
                //plays beep when incorrect key is pressed
                e.Handled = true;
                SystemSounds.Beep.Play();
            }
        }

        private void tbxYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            //accepts only numbers and backspace
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || (int)e.KeyChar == 8)
            {
                //acceptable keystrokes
                e.Handled = false;

            }
            else if ((int)e.KeyChar == 13)
            {
                tbxCard.Focus();
            }
            else
            {
                //plays beep when incorrect key is pressed
                e.Handled = true;
                SystemSounds.Beep.Play();
            }
        }

       
    }
}
