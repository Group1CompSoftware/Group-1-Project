﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group1_CSP
{
    class InputValidation
    {
        public static bool ValidateProductAdd(string productID, string productName, string productPrice, string imageID, string amountInStock)
        {
            int i;
            double d;
            if(int.TryParse(productID, out i) && productName.Length <= 50 && double.TryParse(productPrice, out d) && int.TryParse(imageID, out i) && int.TryParse(amountInStock, out i))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool ValidateEmployeeAdd(string employeeID, string managerID, string employeeName, string username, string password)
        {
            int i;
            if (int.TryParse(employeeID, out i) && int.TryParse(managerID, out i) && employeeName.Length <= 50 && username.Length <= 50 && password.Length <= 50)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool ValidateProductUpdate(string columnName, string newValue)
        {
            int i;
            double d;
            switch (columnName)
            {
                case "ProductID":
                    if (int.TryParse(newValue, out i))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case "ProductName":
                    if (newValue.Length <= 50)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case "ProductPrice":
                    if (double.TryParse(newValue, out d))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case "ImageNumber":
                    if (int.TryParse(newValue, out i))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case "AmountInStock":
                    if (int.TryParse(newValue, out i))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case "ImageFile":
                    return false;
                default:
                    return false;
            }
        }

        public static bool ValidateEmployeeUpdate(string columnName, string newValue)
        {
            int i;
            switch (columnName)
            {
                case "EmployeeID":
                    if (int.TryParse(newValue, out i))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case "ManagerID":
                    if (int.TryParse(newValue, out i))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case "EmployeeName":
                    if (newValue.Length <= 50)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case "EmployeeUsername":
                    if (newValue.Length <= 50)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case "EmployeePassword":
                    if (newValue.Length <= 50)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                default:
                    return false;
            }
        }
    }
}
