﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1_CSP
{
    public partial class frmAddEmployee : Form
    {
        public frmAddEmployee()
        {
            InitializeComponent();
        }

        private void frmAddEmployee_Load(object sender, EventArgs e)
        {

        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if(InputValidation.ValidateEmployeeAdd(tbxEmployeeID.Text, tbxManagerID.Text, tbxEmployeeName.Text, tbxUsername.Text, tbxPassword.Text))
            {
                ProgOps.ManagersInsert("Employees", tbxEmployeeID.Text, tbxManagerID.Text, "'" + tbxEmployeeName.Text + "'", "'" + tbxUsername.Text + "'", "'" + tbxPassword.Text + "'");
                this.Close();
            }
            else
            {
                MessageBox.Show("Input invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
