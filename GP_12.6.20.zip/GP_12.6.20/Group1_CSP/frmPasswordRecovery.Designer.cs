﻿namespace Group1_CSP
{
    partial class frmPasswordRecovery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTip1 = new System.Windows.Forms.Label();
            this.lblTip2 = new System.Windows.Forms.Label();
            this.tbxUsername = new System.Windows.Forms.MaskedTextBox();
            this.tbxEmailAddress = new System.Windows.Forms.MaskedTextBox();
            this.lblTip3 = new System.Windows.Forms.Label();
            this.lblTip4 = new System.Windows.Forms.Label();
            this.btnSendEmail = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTip1
            // 
            this.lblTip1.AutoSize = true;
            this.lblTip1.ForeColor = System.Drawing.Color.White;
            this.lblTip1.Location = new System.Drawing.Point(13, 13);
            this.lblTip1.Name = "lblTip1";
            this.lblTip1.Size = new System.Drawing.Size(195, 13);
            this.lblTip1.TabIndex = 0;
            this.lblTip1.Text = "Enter your username and email address.";
            // 
            // lblTip2
            // 
            this.lblTip2.AutoSize = true;
            this.lblTip2.ForeColor = System.Drawing.Color.White;
            this.lblTip2.Location = new System.Drawing.Point(13, 26);
            this.lblTip2.Name = "lblTip2";
            this.lblTip2.Size = new System.Drawing.Size(278, 13);
            this.lblTip2.TabIndex = 1;
            this.lblTip2.Text = "A randomly generated password will be sent to your email.";
            // 
            // tbxUsername
            // 
            this.tbxUsername.Location = new System.Drawing.Point(94, 42);
            this.tbxUsername.Name = "tbxUsername";
            this.tbxUsername.Size = new System.Drawing.Size(197, 20);
            this.tbxUsername.TabIndex = 2;
            // 
            // tbxEmailAddress
            // 
            this.tbxEmailAddress.Location = new System.Drawing.Point(94, 68);
            this.tbxEmailAddress.Name = "tbxEmailAddress";
            this.tbxEmailAddress.Size = new System.Drawing.Size(197, 20);
            this.tbxEmailAddress.TabIndex = 3;
            // 
            // lblTip3
            // 
            this.lblTip3.AutoSize = true;
            this.lblTip3.ForeColor = System.Drawing.Color.White;
            this.lblTip3.Location = new System.Drawing.Point(13, 45);
            this.lblTip3.Name = "lblTip3";
            this.lblTip3.Size = new System.Drawing.Size(58, 13);
            this.lblTip3.TabIndex = 4;
            this.lblTip3.Text = "Username:";
            // 
            // lblTip4
            // 
            this.lblTip4.AutoSize = true;
            this.lblTip4.ForeColor = System.Drawing.Color.White;
            this.lblTip4.Location = new System.Drawing.Point(12, 71);
            this.lblTip4.Name = "lblTip4";
            this.lblTip4.Size = new System.Drawing.Size(76, 13);
            this.lblTip4.TabIndex = 5;
            this.lblTip4.Text = "Email Address:";
            // 
            // btnSendEmail
            // 
            this.btnSendEmail.Location = new System.Drawing.Point(16, 98);
            this.btnSendEmail.Name = "btnSendEmail";
            this.btnSendEmail.Size = new System.Drawing.Size(75, 23);
            this.btnSendEmail.TabIndex = 6;
            this.btnSendEmail.Text = "Send Email";
            this.btnSendEmail.UseVisualStyleBackColor = true;
            this.btnSendEmail.Click += new System.EventHandler(this.btnSendEmail_Click);
            // 
            // frmPasswordRecovery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(309, 137);
            this.Controls.Add(this.btnSendEmail);
            this.Controls.Add(this.lblTip4);
            this.Controls.Add(this.lblTip3);
            this.Controls.Add(this.tbxEmailAddress);
            this.Controls.Add(this.tbxUsername);
            this.Controls.Add(this.lblTip2);
            this.Controls.Add(this.lblTip1);
            this.Name = "frmPasswordRecovery";
            this.Text = "Password Recovery";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTip1;
        private System.Windows.Forms.Label lblTip2;
        private System.Windows.Forms.MaskedTextBox tbxUsername;
        private System.Windows.Forms.MaskedTextBox tbxEmailAddress;
        private System.Windows.Forms.Label lblTip3;
        private System.Windows.Forms.Label lblTip4;
        private System.Windows.Forms.Button btnSendEmail;
    }
}