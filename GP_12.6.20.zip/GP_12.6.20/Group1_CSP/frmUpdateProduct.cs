﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Group1_CSP
{
    public partial class frmUpdateProduct : Form
    {
        string imageLocation;

        public frmUpdateProduct()
        {
            InitializeComponent();
        }

        private void frmUpdateProduct_Load(object sender, EventArgs e)
        {
            ProgOps.ManagersQuery(dgvProductsTable, "Products");
            for (int i = 0; i < dgvProductsTable.Rows.Count - 1; i++)
            {
                cbxProductNames.Items.Add(dgvProductsTable.Rows[i].Cells[1].Value.ToString());
            }
        }

        private void cbxProductNames_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < dgvProductsTable.Columns.Count; i++)
            {
                cbxColumnName.Items.Add(dgvProductsTable.Columns[i].Name.ToString());
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            //Sees if value in first cbx is valid
            bool valid1 = false;
            for (int i = 0; i < cbxProductNames.Items.Count; i++)
            {
                if (cbxProductNames.Text == cbxProductNames.Items[i].ToString())
                {
                    valid1 = true;
                }
            }

            //Sees if value in second cbx is valid
            bool valid2 = false;
            for (int i = 0; i < cbxColumnName.Items.Count; i++)
            {
                if (cbxColumnName.Text == cbxColumnName.Items[i].ToString())
                {
                    valid2 = true;
                }
            }

            //Sees if input is valid
            bool valid3 = InputValidation.ValidateProductUpdate(cbxColumnName.Text.ToString(), tbxNewValue.Text.ToString());

            //If all are valid does the thing it needs to do; else sends error mmessage
            if(valid1 && valid2 && valid3 || valid1 && valid2 && cbxColumnName.Text.Contains("ImageFile"))
            {
                int i = 0;
                string newValue;
                if(int.TryParse(tbxNewValue.Text.ToString(), out i))
                {
                    newValue = tbxNewValue.Text.ToString();
                }
                else
                {
                    newValue = "'" + tbxNewValue.Text.ToString() + "'";
                }

                if(cbxColumnName.Text.Contains("ImageFile"))
                {
                    byte[] imageBytes = null;
                    FileStream fileStream = new FileStream(imageLocation, FileMode.Open, FileAccess.Read);
                    BinaryReader binaryReader = new BinaryReader(fileStream);
                    imageBytes = binaryReader.ReadBytes((int)fileStream.Length);

                    string condition = "ProductName = '" + cbxProductNames.Text.ToString() + "'";
                    ProgOps.ManagersUpdate("Products", cbxColumnName.Text.ToString(), condition, newValue, imageBytes);
                    this.Close();
                }
                else
                {
                    string condition = "ProductName = '" + cbxProductNames.Text.ToString() + "'";
                    ProgOps.ManagersUpdate("Products", cbxColumnName.Text.ToString(), condition, newValue);
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Input invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbxColumnName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cbxColumnName.Text.ToString().Contains("ImageFile"))
            {
                tbxNewValue.Visible = false;
                pbxSelectedImage.Visible = true;
                btnSelectImage.Visible = true;
            }
            else
            {
                tbxNewValue.Visible = true;
                pbxSelectedImage.Visible = false;
                btnSelectImage.Visible = false;
            }
        }

        private void btnSelectImage_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog OFD = new OpenFileDialog();
                OFD.Filter = "Image files (*.jpg, *.png)|*.jpg; *.png;";
                OFD.Title = "Select product image";
                if (OFD.ShowDialog() == DialogResult.OK)
                {
                    imageLocation = OFD.FileName.ToString();
                    pbxSelectedImage.ImageLocation = imageLocation;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
