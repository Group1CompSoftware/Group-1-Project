﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1_CSP
{
    public partial class frmRemoveEmployee : Form
    {
        public frmRemoveEmployee()
        {
            InitializeComponent();
        }

        private void frmRemoveEmployee_Load(object sender, EventArgs e)
        {
            ProgOps.ManagersQuery(dgvNameHolder, "Employees");
            for(int i = 0; i < dgvNameHolder.Rows.Count - 1; i++)
            {
                cbxEmployees.Items.Add(dgvNameHolder.Rows[i].Cells[2].Value.ToString());
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            //Does what it needs to do if value in cbx is valid
            bool valid = false;
            for (int i = 0; i < cbxEmployees.Items.Count; i++)
            {
                if (cbxEmployees.Text == cbxEmployees.Items[i].ToString())
                {
                    ProgOps.ManagersDelete("Employees", "EmployeeName = '" + cbxEmployees.SelectedItem.ToString() + "'");
                    this.Close();
                    valid = true;
                }
            }
            if (!valid)
            {
                MessageBox.Show("Input invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
