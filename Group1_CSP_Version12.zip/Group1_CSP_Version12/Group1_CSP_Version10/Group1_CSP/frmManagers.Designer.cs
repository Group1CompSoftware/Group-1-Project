﻿namespace Group1_CSP
{
    partial class frmManagers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvManagersView = new System.Windows.Forms.DataGridView();
            this.btnDisplayProducts = new System.Windows.Forms.Button();
            this.btnDisplayEmployees = new System.Windows.Forms.Button();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.btnAddEmployee = new System.Windows.Forms.Button();
            this.btnRemoveProduct = new System.Windows.Forms.Button();
            this.btnRemoveEmployee = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnChangeProduct = new System.Windows.Forms.Button();
            this.btnChangeEmployee = new System.Windows.Forms.Button();
            this.btnSummary = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvManagersView)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvManagersView
            // 
            this.dgvManagersView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvManagersView.Location = new System.Drawing.Point(195, 12);
            this.dgvManagersView.Name = "dgvManagersView";
            this.dgvManagersView.Size = new System.Drawing.Size(593, 223);
            this.dgvManagersView.TabIndex = 0;
            // 
            // btnDisplayProducts
            // 
            this.btnDisplayProducts.Location = new System.Drawing.Point(12, 12);
            this.btnDisplayProducts.Name = "btnDisplayProducts";
            this.btnDisplayProducts.Size = new System.Drawing.Size(116, 32);
            this.btnDisplayProducts.TabIndex = 1;
            this.btnDisplayProducts.Text = "Display Products";
            this.btnDisplayProducts.UseVisualStyleBackColor = true;
            this.btnDisplayProducts.Click += new System.EventHandler(this.btnDisplayProducts_Click);
            // 
            // btnDisplayEmployees
            // 
            this.btnDisplayEmployees.Location = new System.Drawing.Point(12, 50);
            this.btnDisplayEmployees.Name = "btnDisplayEmployees";
            this.btnDisplayEmployees.Size = new System.Drawing.Size(116, 32);
            this.btnDisplayEmployees.TabIndex = 2;
            this.btnDisplayEmployees.Text = "Display Employees";
            this.btnDisplayEmployees.UseVisualStyleBackColor = true;
            this.btnDisplayEmployees.Click += new System.EventHandler(this.btnDisplayEmployees_Click);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.Location = new System.Drawing.Point(127, 12);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(19, 32);
            this.btnAddProduct.TabIndex = 3;
            this.btnAddProduct.Text = "+";
            this.btnAddProduct.UseVisualStyleBackColor = true;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // btnAddEmployee
            // 
            this.btnAddEmployee.Location = new System.Drawing.Point(127, 50);
            this.btnAddEmployee.Name = "btnAddEmployee";
            this.btnAddEmployee.Size = new System.Drawing.Size(19, 32);
            this.btnAddEmployee.TabIndex = 4;
            this.btnAddEmployee.Text = "+";
            this.btnAddEmployee.UseVisualStyleBackColor = true;
            this.btnAddEmployee.Click += new System.EventHandler(this.btnAddEmployee_Click);
            // 
            // btnRemoveProduct
            // 
            this.btnRemoveProduct.Location = new System.Drawing.Point(145, 12);
            this.btnRemoveProduct.Name = "btnRemoveProduct";
            this.btnRemoveProduct.Size = new System.Drawing.Size(19, 32);
            this.btnRemoveProduct.TabIndex = 5;
            this.btnRemoveProduct.Text = "-";
            this.btnRemoveProduct.UseVisualStyleBackColor = true;
            this.btnRemoveProduct.Click += new System.EventHandler(this.btnRemoveProduct_Click);
            // 
            // btnRemoveEmployee
            // 
            this.btnRemoveEmployee.Location = new System.Drawing.Point(145, 50);
            this.btnRemoveEmployee.Name = "btnRemoveEmployee";
            this.btnRemoveEmployee.Size = new System.Drawing.Size(19, 32);
            this.btnRemoveEmployee.TabIndex = 6;
            this.btnRemoveEmployee.Text = "-";
            this.btnRemoveEmployee.UseVisualStyleBackColor = true;
            this.btnRemoveEmployee.Click += new System.EventHandler(this.btnRemoveEmployee_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(12, 205);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(116, 32);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnChangeProduct
            // 
            this.btnChangeProduct.Location = new System.Drawing.Point(163, 12);
            this.btnChangeProduct.Name = "btnChangeProduct";
            this.btnChangeProduct.Size = new System.Drawing.Size(19, 32);
            this.btnChangeProduct.TabIndex = 8;
            this.btnChangeProduct.Text = "=";
            this.btnChangeProduct.UseVisualStyleBackColor = true;
            this.btnChangeProduct.Click += new System.EventHandler(this.btnChangeProduct_Click);
            // 
            // btnChangeEmployee
            // 
            this.btnChangeEmployee.Location = new System.Drawing.Point(163, 50);
            this.btnChangeEmployee.Name = "btnChangeEmployee";
            this.btnChangeEmployee.Size = new System.Drawing.Size(19, 32);
            this.btnChangeEmployee.TabIndex = 9;
            this.btnChangeEmployee.Text = "=";
            this.btnChangeEmployee.UseVisualStyleBackColor = true;
            this.btnChangeEmployee.Click += new System.EventHandler(this.btnChangeEmployee_Click);
            // 
            // btnSummary
            // 
            this.btnSummary.Location = new System.Drawing.Point(12, 88);
            this.btnSummary.Name = "btnSummary";
            this.btnSummary.Size = new System.Drawing.Size(170, 32);
            this.btnSummary.TabIndex = 10;
            this.btnSummary.Text = "Summary of Orders";
            this.btnSummary.UseVisualStyleBackColor = true;
            this.btnSummary.Click += new System.EventHandler(this.btnSummary_Click);
            // 
            // frmManagers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(800, 249);
            this.Controls.Add(this.btnSummary);
            this.Controls.Add(this.btnChangeEmployee);
            this.Controls.Add(this.btnChangeProduct);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnRemoveEmployee);
            this.Controls.Add(this.btnRemoveProduct);
            this.Controls.Add(this.btnAddEmployee);
            this.Controls.Add(this.btnAddProduct);
            this.Controls.Add(this.btnDisplayEmployees);
            this.Controls.Add(this.btnDisplayProducts);
            this.Controls.Add(this.dgvManagersView);
            this.Name = "frmManagers";
            this.Text = "Managers Menu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmManagers_FormClosing);
            this.Load += new System.EventHandler(this.frmManagers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvManagersView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvManagersView;
        private System.Windows.Forms.Button btnDisplayProducts;
        private System.Windows.Forms.Button btnDisplayEmployees;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Button btnAddEmployee;
        private System.Windows.Forms.Button btnRemoveProduct;
        private System.Windows.Forms.Button btnRemoveEmployee;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnChangeProduct;
        private System.Windows.Forms.Button btnChangeEmployee;
        private System.Windows.Forms.Button btnSummary;
    }
}