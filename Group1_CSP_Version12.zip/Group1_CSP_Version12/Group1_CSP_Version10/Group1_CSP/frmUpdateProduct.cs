﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1_CSP
{
    public partial class frmUpdateProduct : Form
    {
        public frmUpdateProduct()
        {
            InitializeComponent();
        }

        private void frmUpdateProduct_Load(object sender, EventArgs e)
        {
            ProgOps.ManagersQuery(dgvProductsTable, "Products");
            for (int i = 0; i < dgvProductsTable.Rows.Count - 1; i++)
            {
                cbxProductNames.Items.Add(dgvProductsTable.Rows[i].Cells[1].Value.ToString());
            }
        }

        private void cbxProductNames_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < dgvProductsTable.Columns.Count - 1; i++)
            {
                cbxColumnName.Items.Add(dgvProductsTable.Columns[i].Name.ToString());
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            string condition = "ProductName = '" + cbxProductNames.Text.ToString() + "'";
            ProgOps.ManagersUpdate("Products", cbxColumnName.Text.ToString(), tbxNewValue.Text.ToString(), condition);
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
