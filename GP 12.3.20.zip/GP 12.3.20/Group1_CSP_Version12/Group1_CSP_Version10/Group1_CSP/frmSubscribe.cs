﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1_CSP
{
    public partial class frmSubscribe : Form
    {
        public frmSubscribe()
        {
            InitializeComponent();
        }

        private void btnSubscribe_Click(object sender, EventArgs e)
        {
            string username = tbxUsername.Text.ToLower().Trim();

            int membershipCount = ProgOps.CheckMembership(username);
            MessageBox.Show(membershipCount.ToString());

            if (membershipCount > 1)
            {
                //display message
                MessageBox.Show("You are already subscribed to our membership", "Subscription");
            }
            else
            {
                //insert into database
                ProgOps.InsertMembership(username);

                //display message
                MessageBox.Show("Your subscription has been saved", "Subscription");

                //close form
                this.Close();
            }
        }
    }
}
