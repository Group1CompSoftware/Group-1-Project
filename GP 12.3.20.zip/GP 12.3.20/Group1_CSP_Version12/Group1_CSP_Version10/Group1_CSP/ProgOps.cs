﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Drawing;

namespace Group1_CSP
{
    class ProgOps
    {
        //----------------------------------------------------------------------------------------------------
        //Variables and objects

        //Connection string
        private const string CONNECT_STRING = @"Server = cstnt.tstc.edu; Database = inew2330fa20; User Id = group1bfa202330; Password = 1237895";
        //Connection
        private static SqlConnection _cntDatabase = new SqlConnection(CONNECT_STRING);

        //Objects for Customers table
        private static SqlCommand _sqlCustomersCommand = new SqlCommand(); //Command object
        private static SqlDataAdapter _daCustomers = new SqlDataAdapter(); //Data adapter
        private static DataTable _dtCustomersTable = new DataTable(); //Data table

        //Objects for Employees table
        private static SqlCommand _sqlEmployeesCommand = new SqlCommand(); //Command object
        private static SqlDataAdapter _daEmployees = new SqlDataAdapter(); //Data adapter
        private static DataTable _dtEmployeesTable = new DataTable(); //Data table

        //Objects for Products table
        private static SqlCommand _sqlProductsCommand = new SqlCommand(); //Command object
        private static SqlDataAdapter _daProducts = new SqlDataAdapter(); //Data adapter
        private static DataTable _dtProductsTable = new DataTable(); //Data table

        //Objects for Orders table
        private static SqlCommand _sqlOrdersCommand = new SqlCommand(); //Command object
        private static SqlDataAdapter _daOrders = new SqlDataAdapter(); //Data adapter
        private static DataTable _dtOrdersTable = new DataTable(); //Data table

        //for error messages in database
        private static StringBuilder errorMessages = new StringBuilder();

        //----------------------------------------------------------------------------------------------------
        //Getters

        //Getter for Customers table
        public static DataTable CustomersTable
        {
            get { return _dtCustomersTable; }
        }

        //Getter for Employees table
        public static DataTable EmployeesTable
        {
            get { return _dtEmployeesTable; }
        }

        //Getter for Products table
        public static DataTable ProductsTable
        {
            get { return _dtProductsTable; }
        }

        //Getter for Orders table
        public static DataTable OrdersTable
        {
            get { return _dtOrdersTable; }
        }

        //----------------------------------------------------------------------------------------------------
        //Open and close functions

        //Opens database connection
        public static void OpenDatabase()
        {
            //Opens database
            _cntDatabase.Open();
            //Tells user they have connected to the database successfully
            MessageBox.Show("Connection successful.", "Database Connection", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //Closes database and disposes of objects
        public static void CloseDatabase()
        {
            //Closes database
            _cntDatabase.Close();
            //Tells user they have connected to the database successfully
            MessageBox.Show("Closed successfully.", "Database Connection", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //Disposes Customer objects
            _sqlCustomersCommand.Dispose(); //Disposes command object
            _daCustomers.Dispose(); //Disposes data adapter
            _dtCustomersTable.Dispose(); //Disposes data table

            //Disposes Employees objects
            _sqlEmployeesCommand.Dispose(); //Disposes command object
            _daEmployees.Dispose(); //Disposes data adapter
            _dtEmployeesTable.Dispose(); //Disposes data table

            //Disposes Products objects
            _sqlProductsCommand.Dispose(); //Disposes command object
            _daProducts.Dispose(); //Disposes data adapter
            _dtProductsTable.Dispose(); //Disposes data table

            //Disposes Orders objects
            _sqlOrdersCommand.Dispose(); //Disposes command object
            _daOrders.Dispose(); //Disposes data adapter
            _dtOrdersTable.Dispose(); //Disposes data table


        }

        //----------------------------------------------------------------------------------------------------
        //Add any functions needed

        //Ian Fuller - Get logins from Managers table. Username and password are entered by the user, and the form uses an invisible DataGridView to pull up the usernames
        //loginType tells the database which table to pull the logins from
        public static bool UserLogin(string username, string password, DataGridView dgvLoginHolder, string loginType)
        {
            //Creates query (gets logins from database), and a dgv object to put the logins into
            string query = "SELECT " + loginType + "Username, " + loginType + "Password FROM group1bfa202330." + loginType + "s";

            //Creates objects
            SqlCommand _sqlLoginsCommand = new SqlCommand(query, _cntDatabase); //Command object
            SqlDataAdapter _daLogins = new SqlDataAdapter(); //Data adapter
            DataTable _dtLoginsTable = new DataTable(); //Data table

            //Fills invisible table
            _daLogins.SelectCommand = _sqlLoginsCommand; //Data adapter
            _daLogins.Fill(_dtLoginsTable); //Fills table

            //Binds data to the invisible DataGridView
            dgvLoginHolder.DataSource = _dtLoginsTable;

            //Cycles through dgvLoginHolder to find a login that matches the entered information
            for (int i = 0; i < dgvLoginHolder.Rows.Count - 1; i++)
            {
                if (dgvLoginHolder.Rows[i].Cells[0].Value.ToString() == username && dgvLoginHolder.Rows[i].Cells[1].Value.ToString() == password)
                {
                    return true;
                }
            }
            return false;
        }

        //Ian Fuller - Executes query commands for managers
        public static void ManagersQuery(DataGridView dgvManagersView, String tableName)
        {
            //String contains query
            string query = "SELECT * FROM group1bfa202330." + tableName;

            //Creates objects
            SqlCommand _sqlManagersCommand = new SqlCommand(query, _cntDatabase); //Command object
            SqlDataAdapter _daManagers = new SqlDataAdapter(); //Data adapter
            DataTable _dtManagersTable = new DataTable(); //Data table

            //Fills table
            _daManagers.SelectCommand = _sqlManagersCommand; //Sets select command
            _daManagers.Fill(_dtManagersTable); //Fills table

            //Bind controls to datatable
            dgvManagersView.DataSource = _dtManagersTable;
        }

        //Ian Fuller - Executes Insert commands for managers
        public static void ManagersInsert(string tableName, string value1, string value2, string value3, string value4, string value5)
        {
            if (tableName == "Products")
            {
                try
                {
                    string query = "INSERT INTO group1bfa202330.Products (ProductID, ProductName, ProductPrice, ImageNumber, AmountInStock) VALUES (" + value1 + ", " + value2 + ", " + value3 + ", " + value4 + ", " + value5 + ")";
                    SqlCommand _sqlCommand = new SqlCommand(query, _cntDatabase);
                    _sqlCommand.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    if (ex is SqlException)
                    {
                        for (int i = 0; i < ex.Errors.Count; i++)
                        {
                            errorMessages.Append("Index #" + i + "\n" +
                                "Message: " + ex.Errors[i].Message + "\n" +
                                "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                                "Source: " + ex.Errors[i].Source + "\n" +
                                "Procedure: " + ex.Errors[i].Procedure + "\n");
                        }
                        MessageBox.Show(errorMessages.ToString(), "Error Update Products", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show(ex.Message + "Error (PO7)", "Error Update Products", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else if (tableName == "Employees")
            {
                try
                {
                    string query = "INSERT INTO group1bfa202330.Employees (EmployeeID, ManagerID, EmployeeName, EmployeeUsername, EmployeePassword) VALUES (" + value1 + ", " + value2 + ", " + value3 + ", " + value4 + ", " + value5 + ")";
                    SqlCommand _sqlCommand = new SqlCommand(query, _cntDatabase);
                    _sqlCommand.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    if (ex is SqlException)
                    {
                        for (int i = 0; i < ex.Errors.Count; i++)
                        {
                            errorMessages.Append("Index #" + i + "\n" +
                                "Message: " + ex.Errors[i].Message + "\n" +
                                "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                                "Source: " + ex.Errors[i].Source + "\n" +
                                "Procedure: " + ex.Errors[i].Procedure + "\n");
                        }
                        MessageBox.Show(errorMessages.ToString(), "Error Update Products", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show(ex.Message + "Error (PO7)", "Error Update Products", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        //Ian Fuller - Executes Update commands for managers
        public static void ManagersUpdate(string tableName, string columnName, string newValue, string condition)
        {
            try
            {
                string query = "UPDATE group1bfa202330." + tableName + " SET " + columnName + " = " + newValue + " WHERE " + condition;
                SqlCommand _sqlCommand = new SqlCommand(query, _cntDatabase);
                _sqlCommand.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error Update Products", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message + "Error (PO7)", "Error Update Products", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        //Ian Fuller - Executes Delete commands for managers
        public static void ManagersDelete(string tableName, string condition)
        {
            try
            {
                string query = "DELETE FROM group1bfa202330." + tableName + " WHERE " + condition;
                SqlCommand _sqlCommand = new SqlCommand(query, _cntDatabase);
                _sqlCommand.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error Update Products", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message + "Error (PO7)", "Error Update Products", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        //Ceciila Brissett - Fills labels with AmountInStock according to the ProductName
        public static void AmountInStockCommand(Label lblQuantity, string productName)
        {
            try
            {
                string query = "SELECT AmountInStock FROM group1bfa202330.Products WHERE ProductName like '" +
                    productName + "'";

                //establish command object
                _sqlProductsCommand = new SqlCommand(query, _cntDatabase);
                //establish data adapter
                _daProducts = new SqlDataAdapter();
                _daProducts.SelectCommand = _sqlProductsCommand;
                //fill data table
                _dtProductsTable = new DataTable();
                _daProducts.Fill(_dtProductsTable);

                lblQuantity.DataBindings.Add("Text", _dtProductsTable, "AmountInStock");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in AmountInStock", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }


        }

        //Ceciila Brissett - Inserts into Membership Table
        public static void InsertMembership(string username)
        {
            try
            {
                string query = "INSERT INTO group1bfa202330.Membership (CustomerID, CustomerUsername) " +
                    "VALUES((SELECT CustomerID FROM group1bfa202330.Customers WHERE CustomerUsername = '" + username + "'), '" +
                    username + "' )";
                SqlCommand _sqlCommand = new SqlCommand(query, _cntDatabase);
                _sqlCommand.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error Insert Membership", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message + "Error (PO7)", "Error Insert Membership", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }


        }


        //Ceciila Brissett - Deletes from Membership Table
        public static void DeleteMembership(string username)
        {
            try
            {
                string query = "DELETE FROM group1bfa202330.Membership WHERE CustomerUsername = '" + username + "'";
                SqlCommand _sqlCommand = new SqlCommand(query, _cntDatabase);
                _sqlCommand.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error Insert Membership", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message + "Error (PO7)", "Error Insert Membership", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }


        }

        //Ceciila Brissett - Checks for duplicates in Membership table
        public static int CheckMembership(string username)
        {
            
            try
            {
                string query = "SELECT COUNT(*) FROM group1bfa202330.Membership WHERE CustomerUsername LIKE '" + username + "'";
                SqlCommand _sqlCommand = new SqlCommand(query, _cntDatabase);
                _sqlCommand.ExecuteNonQuery();

                int count = (int)_sqlCommand.ExecuteScalar();

                return count;

            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error  Membership", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message + "Error (PO7)", "Error  Membership", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        //Ceciila Brissett - Fills labels with ProductPrice according to the ProductName
        public static void ProductPriceCommand(Label lblPrice, string productName)
        {
            try
            {
                string query = "SELECT ProductPrice FROM group1bfa202330.Products WHERE ProductName like '" +
                    productName + "'";

                //string query = "SELECT ROUND(ProductPrice, 2)  FROM group1bfa202330.Products WHERE ProductName like '" +
                //   productName + "'";


                //establish command object
                _sqlProductsCommand = new SqlCommand(query, _cntDatabase);
                //establish data adapter
                _daProducts = new SqlDataAdapter();
                _daProducts.SelectCommand = _sqlProductsCommand;
                //fill data table
                _dtProductsTable = new DataTable();
                _daProducts.Fill(_dtProductsTable);

                lblPrice.DataBindings.Add("Text", _dtProductsTable, "ProductPrice");
           
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in ProductPrice", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }


        }

        //Cecilia Brissett -  Updates AmountInStock when customers purchases product 
        public static void UpdateAmountInStock(string newValue, string condition)
        {
            try
            {
                string query = "UPDATE group1bfa202330.Products SET AmountInStock = " + newValue + " WHERE ProductName = " + condition;
                SqlCommand _sqlCommand = new SqlCommand(query, _cntDatabase);
                _sqlCommand.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error Update Products", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message + "Error (PO7)", "Error Update Products", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        //Cecilia Brissett - converts to image 
        public static void b_Format(object sender, ConvertEventArgs e)
        {
            byte[] b = (byte[])e.Value;

            System.IO.MemoryStream ms = new System.IO.MemoryStream(b);

            Bitmap bmp;
            bmp = new Bitmap(ms);

            ms.Close();

            e.Value = bmp;
        }

        //Ceciila Brissett - Fills labels with ProductPrice according to the ProductName
        public static void ImagesCommand(PictureBox pbxPic, string productName)
        {
            try
            {
                string query = "SELECT ImageFile FROM group1bfa202330.Products WHERE ProductName like '" +
                    productName + "'";

                //establish command object
                _sqlProductsCommand = new SqlCommand(query, _cntDatabase);
                //establish data adapter
                _daProducts = new SqlDataAdapter();
                _daProducts.SelectCommand = _sqlProductsCommand;
                //fill data table
                _dtProductsTable = new DataTable();
                _daProducts.Fill(_dtProductsTable);


                Binding b = new Binding("Image", _dtProductsTable, "ImageFile");

                b.Format += new ConvertEventHandler(b_Format);

                pbxPic.DataBindings.Add(b);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in ImageFile", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }


        }


        //William Holder - Employees command
        public static void EmployeesDatabaseCommand(DataGridView dgvEmployeesView)
        {
            string query = "SELECT o.OrderID, c.CustomerName, p.ProductName, o.ProductQuantity, (p.ProductPrice * o.ProductQuantity) AS Total" +
                " FROM group1bfa202330.Orders o JOIN group1bfa202330.Customers c ON o.CustomerID = c.CustomerID JOIN group1bfa202330.Products p ON o.ProductID = p.ProductID";

            SqlCommand _sqlEmployeesCommand = new SqlCommand(query, _cntDatabase);
            SqlDataAdapter _daEmployees = new SqlDataAdapter();
            DataTable _dtEmployeesTable = new DataTable();

            _daEmployees.SelectCommand = _sqlEmployeesCommand;
            _daEmployees.Fill(_dtEmployeesTable);

            dgvEmployeesView.DataSource = _dtEmployeesTable;
        }

        //William Holder - Employees Delete Order
        public static void EmployeesDelete(int id)
        {
            DialogResult deleteConfirm = MessageBox.Show("Are you sure? This cannot be undone.", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (deleteConfirm == DialogResult.Yes)
            {
                string query = "DELETE group1bfa202330.Orders WHERE OrderID = " + id.ToString();

                SqlCommand _sqlEmployeesCommand = new SqlCommand(query, _cntDatabase);
                SqlDataAdapter _daEmployees = new SqlDataAdapter();
                DataTable _dtEmployeesTable = new DataTable();

                _daEmployees.SelectCommand = _sqlEmployeesCommand;
                _daEmployees.Fill(_dtEmployeesTable);
            }
        }

        //William Holder - Order Verification
        public static bool OrderVerify(int id)
        {
            string query = "SELECT * FROM group1bfa202330.Orders WHERE OrderID = " + id.ToString();

            SqlCommand _sqlEmployeesCommand = new SqlCommand(query, _cntDatabase);
            SqlDataAdapter _daEmployees = new SqlDataAdapter();
            DataTable _dtEmployeesTable = new DataTable();

            _daEmployees.SelectCommand = _sqlEmployeesCommand;
            _daEmployees.Fill(_dtEmployeesTable);

            if (_dtEmployeesTable.Rows.Count == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //William Holder - Update Employees
        public static void UpdateEmployees(int id, string cName, string iName, int quantity)
        {
            DialogResult updateConfirm = MessageBox.Show("Are you sure? This cannot be undone.", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (updateConfirm == DialogResult.Yes)
            {
                try
                {
                    string query = "UPDATE group1bfa202330.Orders " +
                                    "SET ProductQuantity = '" + quantity.ToString() + "', " +
                                    "CustomerID = (SELECT CustomerID FROM group1bfa202330.Customers c WHERE CustomerName = '" + cName + "'), " +
                                    "ProductID = (SELECT ProductID FROM group1bfa202330.Products p WHERE ProductName = '" + iName + "') " +
                                    "WHERE OrderID = " + id.ToString();

                    SqlCommand _sqlEmployeesCommand = new SqlCommand(query, _cntDatabase);
                    _sqlEmployeesCommand.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Update was unsuccessful. Please check that all input fields are valid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

    }
}
