﻿namespace Group1_CSP
{
    partial class frmUpdateEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbxEmployeeNames = new System.Windows.Forms.ComboBox();
            this.lblTip = new System.Windows.Forms.Label();
            this.lblSet = new System.Windows.Forms.Label();
            this.cbxColumnName = new System.Windows.Forms.ComboBox();
            this.lblTo = new System.Windows.Forms.Label();
            this.tbxNewValue = new System.Windows.Forms.TextBox();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.dgvEmployeesTable = new System.Windows.Forms.DataGridView();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployeesTable)).BeginInit();
            this.SuspendLayout();
            // 
            // cbxEmployeeNames
            // 
            this.cbxEmployeeNames.FormattingEnabled = true;
            this.cbxEmployeeNames.Location = new System.Drawing.Point(16, 29);
            this.cbxEmployeeNames.Name = "cbxEmployeeNames";
            this.cbxEmployeeNames.Size = new System.Drawing.Size(189, 21);
            this.cbxEmployeeNames.TabIndex = 0;
            this.cbxEmployeeNames.SelectedIndexChanged += new System.EventHandler(this.cbxProductNames_SelectedIndexChanged);
            // 
            // lblTip
            // 
            this.lblTip.AutoSize = true;
            this.lblTip.ForeColor = System.Drawing.Color.White;
            this.lblTip.Location = new System.Drawing.Point(13, 13);
            this.lblTip.Name = "lblTip";
            this.lblTip.Size = new System.Drawing.Size(201, 13);
            this.lblTip.TabIndex = 1;
            this.lblTip.Text = "Which employee do you want to update?";
            // 
            // lblSet
            // 
            this.lblSet.AutoSize = true;
            this.lblSet.ForeColor = System.Drawing.Color.White;
            this.lblSet.Location = new System.Drawing.Point(13, 64);
            this.lblSet.Name = "lblSet";
            this.lblSet.Size = new System.Drawing.Size(23, 13);
            this.lblSet.TabIndex = 2;
            this.lblSet.Text = "Set";
            // 
            // cbxColumnName
            // 
            this.cbxColumnName.FormattingEnabled = true;
            this.cbxColumnName.Location = new System.Drawing.Point(42, 61);
            this.cbxColumnName.Name = "cbxColumnName";
            this.cbxColumnName.Size = new System.Drawing.Size(116, 21);
            this.cbxColumnName.TabIndex = 3;
            // 
            // lblTo
            // 
            this.lblTo.AutoSize = true;
            this.lblTo.ForeColor = System.Drawing.Color.White;
            this.lblTo.Location = new System.Drawing.Point(164, 64);
            this.lblTo.Name = "lblTo";
            this.lblTo.Size = new System.Drawing.Size(16, 13);
            this.lblTo.TabIndex = 4;
            this.lblTo.Text = "to";
            // 
            // tbxNewValue
            // 
            this.tbxNewValue.Location = new System.Drawing.Point(186, 61);
            this.tbxNewValue.Name = "tbxNewValue";
            this.tbxNewValue.Size = new System.Drawing.Size(116, 20);
            this.tbxNewValue.TabIndex = 5;
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(16, 93);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(189, 23);
            this.btnConfirm.TabIndex = 6;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // dgvEmployeesTable
            // 
            this.dgvEmployeesTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmployeesTable.Location = new System.Drawing.Point(271, 13);
            this.dgvEmployeesTable.Name = "dgvEmployeesTable";
            this.dgvEmployeesTable.Size = new System.Drawing.Size(10, 10);
            this.dgvEmployeesTable.TabIndex = 7;
            this.dgvEmployeesTable.Visible = false;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(16, 122);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(189, 23);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // frmUpdateEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(317, 153);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.dgvEmployeesTable);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.tbxNewValue);
            this.Controls.Add(this.lblTo);
            this.Controls.Add(this.cbxColumnName);
            this.Controls.Add(this.lblSet);
            this.Controls.Add(this.lblTip);
            this.Controls.Add(this.cbxEmployeeNames);
            this.Name = "frmUpdateEmployee";
            this.Text = "Update Employee";
            this.Load += new System.EventHandler(this.frmUpdateEmployee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployeesTable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbxEmployeeNames;
        private System.Windows.Forms.Label lblTip;
        private System.Windows.Forms.Label lblSet;
        private System.Windows.Forms.ComboBox cbxColumnName;
        private System.Windows.Forms.Label lblTo;
        private System.Windows.Forms.TextBox tbxNewValue;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.DataGridView dgvEmployeesTable;
        private System.Windows.Forms.Button btnCancel;
    }
}